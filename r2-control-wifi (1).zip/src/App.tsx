import React, { useState, useEffect } from 'react';
import {
  Wifi,
  WifiOff,
  Eye,
  EyeOff,
  AlertCircle,
  Shield,
  ShieldCheck,
  Home,
  Users,
  Lock,
  ClipboardList,
  Settings,
  LogOut,
  ArrowLeft,
  Smartphone,
  Tv,
  Laptop,
  RotateCw,
  KeyRound,
  CheckCircle2,
  AlertTriangle,
  Ban,
  Check,
  Clock,
  History,
  ChevronRight,
  Activity,
  ChevronDown,
  ChevronUp,
  Radio,
} from 'lucide-react';
import { ConnectedDevice } from './types/device';
import {
  LocalNetworkInfo,
  RouterDetectionResult,
  RouterCapability,
  RouterSessionState,
  NetworkMatchStatus,
} from './types/network';
import { getConnectedDevicesFromRouter } from './services/routerService';
import { getLocalNetworkInfo } from './services/androidNetworkBridge';
import { detectLocalRouter } from './services/routerDetector';
import { checkRouterCapability } from './services/routerCapabilityChecker';
import { RouterSessionManager } from './services/routerSessionManager';

interface HistoryLogItem {
  id: string;
  badgeEmoji: string;
  time: string;
  title: string;
  description: string;
  type: 'success' | 'danger' | 'info' | 'auth';
}

export default function App() {
  // Navigation: 'login' | 'dashboard' | 'devices' | 'wifi_settings' | 'protection' | 'history' | 'settings'
  const [currentPage, setCurrentPage] = useState<
    'login' | 'dashboard' | 'devices' | 'wifi_settings' | 'protection' | 'history' | 'settings'
  >(() => {
    const sessionMgr = RouterSessionManager.getInstance();
    return sessionMgr.isRouterPaired() && !sessionMgr.isSessionExpired() ? 'dashboard' : 'login';
  });

  // Modal Keluar Akun State
  const [showLogoutModal, setShowLogoutModal] = useState(false);

  // ==========================================
  // State Jaringan & Deteksi Router Lokal
  // ==========================================
  const [networkInfo, setNetworkInfo] = useState<LocalNetworkInfo>({
    isConnectedToWifi: true,
    networkType: 'wifi',
    ssid: 'Tidak tersedia',
    bssid: 'Tidak tersedia',
    deviceIp: 'Tidak tersedia',
    gatewayIp: '192.168.1.1',
    subnet: '255.255.255.0',
    permissionGranted: false,
    lastUpdated: '',
  });

  const [routerDetection, setRouterDetection] = useState<RouterDetectionResult>({
    isDetected: false,
    gatewayAddress: '192.168.1.1',
    identity: 'Belum berhasil diidentifikasi',
    probeSummary: 'Memulai pemeriksaan gateway lokal...',
    probeDurationMs: 0,
    timestamp: '',
  });

  const [routerCapability, setRouterCapability] = useState<RouterCapability>({
    gatewayReachable: false,
    httpAvailable: false,
    httpsAvailable: false,
    localAdminPageDetected: 'Tidak diketahui',
    detectedVendor: 'Belum diketahui',
    detectedModel: 'Belum diketahui',
    supportedAccessMethods: ['Belum diketahui'],
    checkedAt: '',
    status: 'Menunggu pemeriksaan...',
  });

  // State Autentikasi & Sesi Router (Tahap 3 - Router Authentication)
  const [authStatus, setAuthStatus] = useState<'Belum dilakukan' | 'Berhasil' | 'Gagal' | 'Terhubung'>('Belum dilakukan');
  const [routerSessionState, setRouterSessionState] = useState<RouterSessionState>('DETECTED');
  const [networkMatch, setNetworkMatch] = useState<NetworkMatchStatus>('UNPAIRED');
  const [showAuthForm, setShowAuthForm] = useState(false);

  const [isDetectingRouter, setIsDetectingRouter] = useState(false);
  const [showDiagnostics, setShowDiagnostics] = useState(true);

  // Login form states
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('persib1933');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Router devices state (Tahap 3 - Preview UI)
  const [devices, setDevices] = useState<ConnectedDevice[]>([]);
  const [isFetchingDevices, setIsFetchingDevices] = useState(false);

  // Wi-Fi Settings State (Tahap 4)
  const [wifiSsid, setWifiSsid] = useState('Rumah Sifa');
  const [wifiPassword, setWifiPassword] = useState('sifa@wifi2026');
  const [showWifiPassword, setShowWifiPassword] = useState(false);
  const [showChangePasswordForm, setShowChangePasswordForm] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [passwordFormError, setPasswordFormError] = useState('');
  const [passwordSuccessMessage, setPasswordSuccessMessage] = useState('');
  const [isEditingSsid, setIsEditingSsid] = useState(false);
  const [tempSsid, setTempSsid] = useState('Rumah Sifa');
  const [ssidSuccessMessage, setSsidSuccessMessage] = useState('');

  // Perlindungan State (Tahap 5)
  const [unknownDevice, setUnknownDevice] = useState<{
    name: string;
    emoji: string;
    firstSeen: string;
    status: 'pending' | 'allowed' | 'blocked';
  }>({
    name: 'Redmi Note 13',
    emoji: '📱',
    firstSeen: '11:42',
    status: 'pending',
  });

  const [blockedDevices, setBlockedDevices] = useState<
    Array<{
      id: string;
      name: string;
      emoji: string;
      reason: string;
    }>
  >([
    {
      id: 'blocked-1',
      name: 'iPhone',
      emoji: '📱',
      reason: 'Akses ke Wi-Fi diblokir',
    },
  ]);

  const [protectionToast, setProtectionToast] = useState<string | null>(null);

  // Riwayat State (Tahap 6)
  const historyLogs: HistoryLogItem[] = [
    {
      id: 'log-5',
      badgeEmoji: '🛜',
      time: '13:25',
      title: 'Nama Wi-Fi',
      description: 'Berhasil diubah',
      type: 'info',
    },
    {
      id: 'log-4',
      badgeEmoji: '🔐',
      time: '13:10',
      title: 'Password Wi-Fi',
      description: 'Berhasil diubah',
      type: 'auth',
    },
    {
      id: 'log-3',
      badgeEmoji: '🟢',
      time: '12:05',
      title: 'Redmi Note 13',
      description: 'Perangkat diizinkan',
      type: 'success',
    },
    {
      id: 'log-2',
      badgeEmoji: '🔴',
      time: '11:43',
      title: 'Redmi Note 13',
      description: 'Perangkat diblokir',
      type: 'danger',
    },
    {
      id: 'log-1',
      badgeEmoji: '🟢',
      time: '11:42',
      title: 'Redmi Note 13',
      description: 'Perangkat baru terdeteksi',
      type: 'success',
    },
  ];

  // Pengaturan State (Tahap 7)
  const [notifyNewDevice, setNotifyNewDevice] = useState(true);
  const [notifyBlockedDevice, setNotifyBlockedDevice] = useState(true);
  const [settingsToast, setSettingsToast] = useState<string | null>(null);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Fungsi pemeriksaan status jaringan & deteksi router lokal
  const runLocalNetworkCheck = async () => {
    setIsDetectingRouter(true);
    try {
      // 1. Ambil info jaringan Android
      const netInfo = await getLocalNetworkInfo();
      setNetworkInfo(netInfo);

      const sessionMgr = RouterSessionManager.getInstance();
      const match = sessionMgr.evaluateNetwork(netInfo);
      setNetworkMatch(match);

      // 2. Jika terhubung Wi-Fi dan ada gateway, lakukan pemeriksaan lokal ke gateway & capability check
      if (netInfo.isConnectedToWifi && netInfo.gatewayIp && netInfo.gatewayIp !== 'Tidak tersedia') {
        sessionMgr.setVerifiedGateway(netInfo.gatewayIp);
        const [detection, capability] = await Promise.all([
          detectLocalRouter(netInfo.gatewayIp),
          checkRouterCapability(netInfo.gatewayIp),
        ]);
        setRouterDetection(detection);
        setRouterCapability(capability);
      } else {
        // Jika tidak terhubung Wi-Fi
        const nowStr = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        setRouterDetection({
          isDetected: false,
          gatewayAddress: netInfo.gatewayIp || 'Tidak tersedia',
          identity: 'Identitas router belum diketahui',
          probeSummary: 'Kontrol router tidak tersedia - Tidak terhubung ke Wi-Fi.',
          probeDurationMs: 0,
          timestamp: nowStr,
        });
        setRouterCapability({
          gatewayReachable: false,
          httpAvailable: false,
          httpsAvailable: false,
          localAdminPageDetected: 'Tidak tersedia',
          detectedVendor: 'Belum diketahui',
          detectedModel: 'Belum diketahui',
          supportedAccessMethods: ['Tidak tersedia'],
          checkedAt: nowStr,
          status: 'Kontrol router tidak tersedia - Tidak terhubung ke Wi-Fi.',
        });
      }
    } catch (err) {
      console.error('Error saat deteksi jaringan lokal:', err);
    } finally {
      setIsDetectingRouter(false);
    }
  };

  // Load router devices
  const loadDevices = async () => {
    setIsFetchingDevices(true);
    try {
      const data = await getConnectedDevicesFromRouter();
      setDevices(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsFetchingDevices(false);
    }
  };

  useEffect(() => {
    const sessionMgr = RouterSessionManager.getInstance();

    // Berlangganan ke RouterSessionManager untuk memantau status sesi router
    const unsubscribeSession = sessionMgr.subscribe((state, metadata, match) => {
      setRouterSessionState(state);
      setNetworkMatch(match);
      if (state === 'AUTHENTICATED') {
        setAuthStatus('Terhubung');
      } else if (state === 'AUTH_FAILED') {
        setAuthStatus('Gagal');
      } else {
        setAuthStatus('Belum dilakukan');
      }
    });

    runLocalNetworkCheck().then(() => {
      // Jika router sudah terhubung sebelumnya dan sesi valid di Wi-Fi yang sama:
      // langsung tampilkan Dashboard tanpa meminta username/password router!
      if (sessionMgr.isRouterPaired() && sessionMgr.isSessionActive()) {
        setCurrentPage('dashboard');
      } else if (!sessionMgr.isRouterPaired()) {
        setCurrentPage('login');
      }
    });

    loadDevices();

    // Listener otomatis saat status koneksi jaringan berubah
    const handleOnline = () => runLocalNetworkCheck();
    const handleOffline = () => {
      const offlineInfo: LocalNetworkInfo = {
        isConnectedToWifi: false,
        networkType: 'offline',
        ssid: 'Tidak tersedia',
        bssid: 'Tidak tersedia',
        deviceIp: 'Tidak tersedia',
        gatewayIp: 'Tidak tersedia',
        subnet: 'Tidak tersedia',
        permissionGranted: false,
        lastUpdated: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      };
      setNetworkInfo(offlineInfo);
      setRouterDetection((prev) => ({
        ...prev,
        isDetected: false,
        identity: 'Identitas router belum diketahui',
        probeSummary: 'Kontrol router tidak tersedia - Tidak terhubung ke Wi-Fi.',
      }));
      setRouterCapability((prev) => ({
        ...prev,
        gatewayReachable: false,
        status: 'Kontrol router tidak tersedia - Tidak terhubung ke Wi-Fi.',
      }));
      sessionMgr.evaluateNetwork(offlineInfo);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      unsubscribeSession();
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Handler Autentikasi Router (Tahap 3)
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!username.trim()) {
      setErrorMessage('Nama pengguna router harus diisi');
      return;
    }

    if (!password) {
      setErrorMessage('Password router harus diisi');
      return;
    }

    // 1. Verifikasi koneksi Wi-Fi
    if (!networkInfo.isConnectedToWifi) {
      setErrorMessage('Router tidak dapat dijangkau melalui jaringan lokal. Periksa koneksi Wi-Fi.');
      return;
    }

    setIsLoading(true);

    try {
      const sessionMgr = RouterSessionManager.getInstance();
      const authResult = await sessionMgr.authenticate(
        { username, password },
        routerCapability,
        networkInfo
      );

      setIsLoading(false);

      if (authResult.success) {
        setAuthStatus('Berhasil');
        setCurrentPage('dashboard');
      } else {
        setAuthStatus('Gagal');
        // Tampilkan pesan kegagalan secara jelas tanpa menampilkan password
        setErrorMessage(
          authResult.statusMessage === 'Pemeriksaan router membutuhkan Android native bridge.'
            ? 'Pemeriksaan router membutuhkan Android native bridge.'
            : (authResult.errorMessage || 'Autentikasi gagal. Periksa kembali kredensial akun router.')
        );
      }
    } catch (err: any) {
      setIsLoading(false);
      setAuthStatus('Gagal');
      setErrorMessage(err?.message || 'Autentikasi gagal');
    }
  };

  const handleConfirmLogout = () => {
    RouterSessionManager.getInstance().logoutRouter().catch(() => {});
    setAuthStatus('Belum dilakukan');
    setShowLogoutModal(false);
    setCurrentPage('login');
    setToastMessage(null);
  };

  const handleMenuClick = (menuKey: string) => {
    if (menuKey === 'PERANGKAT') {
      loadDevices();
      setCurrentPage('devices');
    } else if (menuKey === 'PENGATURAN WI-FI') {
      setCurrentPage('wifi_settings');
    } else if (menuKey === 'PERLINDUNGAN') {
      setCurrentPage('protection');
    } else if (menuKey === 'RIWAYAT') {
      setCurrentPage('history');
    } else if (menuKey === 'PENGATURAN') {
      setCurrentPage('settings');
    }
  };

  // Handler Perlindungan
  const handleAllowDevice = () => {
    setUnknownDevice((prev) => ({ ...prev, status: 'allowed' }));
    setProtectionToast('✅ Redmi Note 13 diizinkan & masuk daftar tepercaya.');
    setTimeout(() => setProtectionToast(null), 3000);
  };

  const handleBlockDevice = () => {
    setUnknownDevice((prev) => ({ ...prev, status: 'blocked' }));
    setBlockedDevices((prev) => [
      ...prev,
      {
        id: `blocked-${Date.now()}`,
        name: unknownDevice.name,
        emoji: unknownDevice.emoji,
        reason: 'Akses ke Wi-Fi diblokir',
      },
    ]);
    setProtectionToast('🔴 Redmi Note 13 berhasil diblokir dari Wi-Fi.');
    setTimeout(() => setProtectionToast(null), 3000);
  };

  const handleUnblockDevice = (id: string, name: string) => {
    setBlockedDevices((prev) => prev.filter((d) => d.id !== id));
    if (name === 'Redmi Note 13') {
      setUnknownDevice((prev) => ({ ...prev, status: 'pending' }));
    }
    setProtectionToast(`Akses Wi-Fi untuk ${name} dibuka kembali.`);
    setTimeout(() => setProtectionToast(null), 3000);
  };

  // Handler simpan password baru
  const handleSavePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordFormError('');
    setPasswordSuccessMessage('');

    if (!newPassword) {
      setPasswordFormError('Password baru harus diisi.');
      return;
    }
    if (newPassword.length < 8) {
      setPasswordFormError('Password minimal harus 8 karakter.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordFormError('Konfirmasi password tidak cocok.');
      return;
    }

    setWifiPassword(newPassword);
    setPasswordSuccessMessage('Password Wi-Fi berhasil diperbarui (Preview UI)');
    setNewPassword('');
    setConfirmPassword('');
    setTimeout(() => {
      setPasswordSuccessMessage('');
      setShowChangePasswordForm(false);
    }, 2000);
  };

  // Handler simpan nama Wi-Fi
  const handleSaveSsid = () => {
    if (tempSsid.trim()) {
      setWifiSsid(tempSsid.trim());
      setIsEditingSsid(false);
      setSsidSuccessMessage('Nama Wi-Fi berhasil diperbarui (Preview UI)');
      setTimeout(() => setSsidSuccessMessage(''), 2500);
    }
  };

  const triggerSettingFeedback = (featureName: string) => {
    setSettingsToast(`Menu "${featureName}" aktif.`);
    setTimeout(() => setSettingsToast(null), 2500);
  };

  return (
    <div className="min-h-screen bg-[#072460] flex flex-col items-center justify-center p-3 sm:p-5 font-sans relative overflow-x-hidden select-none">
      
      {/* Background Sporty Biru Khas Persib */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden opacity-60">
        <div className="absolute top-0 left-0 right-0 h-96 bg-gradient-to-b from-[#0D4CB5] to-transparent" />
        <div className="absolute -top-32 -right-32 w-96 h-96 rounded-full bg-[#1A62D6]/30 blur-3xl" />
        <div className="absolute -bottom-32 -left-32 w-96 h-96 rounded-full bg-[#051C4D]/60 blur-3xl" />
        <div className="absolute -right-20 top-1/4 w-80 h-3 bg-gradient-to-r from-transparent via-white/10 to-transparent rotate-[-35deg]" />
        <div className="absolute -left-20 bottom-1/4 w-80 h-3 bg-gradient-to-r from-transparent via-white/10 to-transparent rotate-[-35deg]" />
      </div>

      {/* Main Container Mobile Phone / Screen */}
      <div className="w-full max-w-[420px] relative z-10 my-auto">
        
        {/* ========================================================
            MODAL KONFIRMASI: KELUAR AKUN?
           ======================================================== */}
        {showLogoutModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
            <div className="w-full max-w-[340px] bg-white rounded-3xl p-6 sm:p-7 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.6)] border-2 border-white text-center animate-in zoom-in-95 duration-200 text-[#08296B]">
              <div className="w-14 h-14 rounded-2xl bg-red-50 text-red-600 border border-red-200 flex items-center justify-center mx-auto mb-4 shadow-xs">
                <LogOut className="w-7 h-7 stroke-[2.5]" />
              </div>

              <h2 className="text-xl font-black text-[#08296B] tracking-tight uppercase">
                KELUAR AKUN?
              </h2>

              <div className="mt-3 space-y-2 text-xs sm:text-sm font-bold text-slate-600 leading-relaxed">
                <p>
                  Anda akan keluar dari<br />
                  <span className="font-black text-[#0C44AC]">R2 Control WiFi</span>.
                </p>
                <p className="text-slate-500 font-semibold text-xs pt-1 border-t border-slate-100">
                  Perangkat ini tidak lagi<br />
                  menjadi perangkat aktif.
                </p>
              </div>

              <div className="mt-6 grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowLogoutModal(false)}
                  className="h-12 rounded-xl bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-700 font-black text-xs uppercase tracking-wider transition-all border border-slate-200 cursor-pointer"
                >
                  [ BATAL ]
                </button>

                <button
                  type="button"
                  onClick={handleConfirmLogout}
                  className="h-12 rounded-xl bg-red-600 hover:bg-red-700 active:bg-red-800 text-white font-black text-xs uppercase tracking-wider shadow-md shadow-red-600/30 transition-all cursor-pointer"
                >
                  [ KELUAR ]
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================
            HALAMAN TAHAP 2: DASHBOARD
           ======================================================== */}
        {currentPage === 'dashboard' && (
          <div className="bg-gradient-to-b from-[#0C44AC] via-[#0A3B96] to-[#08296B] rounded-3xl border-2 border-white/20 shadow-[0_25px_60px_-10px_rgba(0,0,0,0.5)] overflow-hidden transition-all text-white">
            
            {/* Strip Sporty Atas */}
            <div className="h-2 w-full flex">
              <div className="w-2/5 bg-[#051C4D]" />
              <div className="w-1/5 bg-white" />
              <div className="w-2/5 bg-[#3B82F6]" />
            </div>

            <div className="p-5 sm:p-6">
              
              {/* Header Aplikasi: Besar dan Sangat Tebal */}
              <div className="flex items-center justify-between pb-4 border-b border-white/15">
                <div>
                  <h1 className="text-2xl sm:text-[26px] font-black text-white tracking-tight uppercase leading-none drop-shadow-sm">
                    R2 CONTROL WIFI
                  </h1>
                  <div className="flex items-center gap-1.5 mt-1.5">
                    <span
                      className={`w-2 h-2 rounded-full ${
                        networkInfo.isConnectedToWifi ? 'bg-emerald-400 animate-pulse' : 'bg-red-400'
                      }`}
                    />
                    <span className="text-[11px] font-extrabold text-blue-100 tracking-wider uppercase">
                      {networkInfo.isConnectedToWifi ? 'Panel Kontrol Aktif' : 'Wi-Fi Terputus'}
                    </span>
                  </div>
                </div>

                <div className="w-12 h-12 rounded-2xl bg-white p-1 shadow-md shadow-black/20 flex items-center justify-center shrink-0">
                  <div className="w-full h-full rounded-xl bg-[#0C44AC] flex items-center justify-center">
                    {networkInfo.isConnectedToWifi ? (
                      <Wifi className="w-6 h-6 text-white stroke-[2.4]" />
                    ) : (
                      <WifiOff className="w-6 h-6 text-white stroke-[2.4]" />
                    )}
                  </div>
                </div>
              </div>

              {/* Status Utama Wi-Fi & Indikator Kontrol Router */}
              <div className="mt-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 p-4 text-white shadow-inner relative overflow-hidden">
                <div className="absolute right-0 top-0 bottom-0 w-24 opacity-10 flex items-center justify-center pointer-events-none">
                  <Wifi className="w-28 h-28 stroke-[1.2]" />
                </div>

                <div className="flex items-center justify-between relative z-10">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-white text-[#0C44AC] flex items-center justify-center font-bold shadow-xs">
                      <Home className="w-4 h-4 stroke-[2.5]" />
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-blue-200 block leading-none mb-0.5">
                        Jaringan Aktif
                      </span>
                      <h2 className="text-base font-black tracking-tight leading-none text-white">
                        🏠 {networkInfo.ssid !== 'Tidak tersedia' ? networkInfo.ssid : wifiSsid}
                      </h2>
                    </div>
                  </div>

                  {networkMatch === 'DIFFERENT_WIFI' ? (
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-600 text-white shadow-xs">
                      <span className="text-xs font-black tracking-wider uppercase">
                        🔴 Router rumah tidak tersedia
                      </span>
                    </div>
                  ) : routerSessionState === 'AUTHENTICATED' ? (
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500 text-white shadow-xs">
                      <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                      <span className="text-xs font-black tracking-wider uppercase">
                        🟢 ROUTER TERHUBUNG
                      </span>
                    </div>
                  ) : networkInfo.isConnectedToWifi ? (
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500 text-white shadow-xs">
                      <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                      <span className="text-xs font-black tracking-wider uppercase">
                        🟡 Router Terdeteksi
                      </span>
                    </div>
                  ) : (
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-red-500 text-white shadow-xs">
                      <span className="text-xs font-black tracking-wider uppercase">
                        🔴 Tidak Terhubung
                      </span>
                    </div>
                  )}
                </div>

                {/* Status Peringatan jika Wi-Fi Tidak Terhubung atau Beda Wi-Fi */}
                {networkMatch === 'DIFFERENT_WIFI' ? (
                  <div className="mt-3.5 pt-3 border-t border-white/15 relative z-10 flex items-center gap-2 text-red-200 text-xs font-black">
                    <AlertTriangle className="w-4 h-4 shrink-0 text-red-300" />
                    <span>Hubungkan perangkat ke Wi-Fi rumah untuk mengontrol router.</span>
                  </div>
                ) : !networkInfo.isConnectedToWifi ? (
                  <div className="mt-3.5 pt-3 border-t border-white/15 relative z-10 flex items-center gap-2 text-amber-200 text-xs font-black">
                    <AlertTriangle className="w-4 h-4 shrink-0 text-amber-300" />
                    <span>Kontrol router tidak tersedia - Tidak terhubung ke Wi-Fi.</span>
                  </div>
                ) : (
                  <div className="mt-3.5 pt-3 border-t border-white/15 flex items-center justify-between relative z-10">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center text-white">
                        <Users className="w-3.5 h-3.5 stroke-[2.4]" />
                      </div>
                      <span className="text-xs sm:text-sm font-extrabold text-white tracking-tight">
                        5 perangkat terhubung
                      </span>
                    </div>

                    <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-white text-[#0C44AC]">
                      Sinyal Kuat
                    </span>
                  </div>
                )}
              </div>

              {/* ========================================================
                  KARTU DIAGNOSTIK ROUTER LOKAL (TAHAP DETEKSI ROUTER LOKAL)
                 ======================================================== */}
              <div className="mt-3.5 rounded-2xl bg-white text-[#08296B] shadow-md shadow-black/20 border-2 border-white/40 overflow-hidden">
                <div
                  onClick={() => setShowDiagnostics(!showDiagnostics)}
                  className="p-3.5 flex items-center justify-between cursor-pointer bg-slate-50 hover:bg-blue-50/60 transition-colors border-b border-slate-100"
                >
                  <div className="flex items-center gap-2">
                    <Activity className="w-4 h-4 text-[#0C44AC] stroke-[2.5]" />
                    <span className="text-xs font-black uppercase tracking-wider text-[#08296B]">
                      Diagnostik Router Lokal
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        runLocalNetworkCheck();
                      }}
                      title="Pindai Ulang Gateway"
                      className="p-1 rounded-lg bg-white border border-slate-200 text-[#0C44AC] hover:bg-slate-100"
                    >
                      <RotateCw
                        className={`w-3.5 h-3.5 stroke-[2.5] ${isDetectingRouter ? 'animate-spin' : ''}`}
                      />
                    </button>
                    {showDiagnostics ? (
                      <ChevronUp className="w-4 h-4 text-slate-400" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-400" />
                    )}
                  </div>
                </div>

                {showDiagnostics && (
                  <div className="p-3.5 divide-y divide-slate-100 text-xs font-bold animate-in fade-in duration-150">
                    <div className="pb-2 flex items-center justify-between">
                      <span className="text-slate-500">Router terdeteksi:</span>
                      <span
                        className={`font-black px-2 py-0.5 rounded-full text-[11px] ${
                          routerDetection.isDetected || routerCapability.gatewayReachable
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {routerDetection.isDetected || routerCapability.gatewayReachable ? 'Ya' : 'Tidak'}
                      </span>
                    </div>

                    <div className="py-2 flex items-center justify-between">
                      <span className="text-slate-500">Gateway:</span>
                      <span className="font-mono font-black text-[#0C44AC]">
                        {networkInfo.gatewayIp}
                      </span>
                    </div>

                    <div className="py-2 flex items-center justify-between">
                      <span className="text-slate-500">Gateway merespons:</span>
                      <span
                        className={`font-black px-2 py-0.5 rounded-full text-[11px] ${
                          routerCapability.gatewayReachable
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {routerCapability.gatewayReachable ? 'Ya' : 'Tidak'}
                      </span>
                    </div>

                    <div className="py-2 flex items-center justify-between">
                      <span className="text-slate-500">Autentikasi router:</span>
                      <span
                        className={`font-black px-2 py-0.5 rounded-full text-[11px] ${
                          authStatus === 'Berhasil'
                            ? 'bg-emerald-100 text-emerald-800'
                            : authStatus === 'Gagal'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {authStatus}
                      </span>
                    </div>

                    <div className="py-2 flex items-center justify-between">
                      <span className="text-slate-500">Sesi router:</span>
                      <span
                        className={`font-black px-2 py-0.5 rounded-full text-[11px] ${
                          routerSessionState === 'AUTHENTICATED'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {routerSessionState === 'AUTHENTICATED' ? 'Aktif' : 'Tidak aktif'}
                      </span>
                    </div>

                    <div className="py-2 flex items-center justify-between">
                      <span className="text-slate-500">Metode autentikasi:</span>
                      <span className="font-extrabold text-slate-800 text-[11px]">
                        {routerCapability.supportedAccessMethods.join(', ') || 'Belum diketahui'}
                      </span>
                    </div>

                    <div className="py-2 flex items-center justify-between">
                      <span className="text-slate-500">Router:</span>
                      <span className="font-extrabold text-slate-800 text-[11px] max-w-[200px] text-right truncate">
                        {routerCapability.detectedVendor !== 'Belum diketahui'
                          ? `${routerCapability.detectedVendor} ${routerCapability.detectedModel !== 'Belum diketahui' ? routerCapability.detectedModel : ''}`.trim()
                          : (routerDetection.identity !== 'Identitas router belum diketahui' && routerDetection.identity !== 'Belum berhasil diidentifikasi'
                            ? routerDetection.identity
                            : 'Belum diketahui')}
                      </span>
                    </div>

                    <div className="py-2 flex items-center justify-between">
                      <span className="text-slate-500">Admin lokal:</span>
                      <span className="font-extrabold text-slate-800 text-[11px]">
                        {routerCapability.localAdminPageDetected}
                      </span>
                    </div>

                    <div className="py-2 flex items-center justify-between">
                      <span className="text-slate-500">Wi-Fi:</span>
                      <span className="font-extrabold text-[#08296B]">
                        {networkInfo.ssid}
                      </span>
                    </div>

                    <div className="py-2 flex items-center justify-between">
                      <span className="text-slate-500">BSSID:</span>
                      <span className="font-mono text-[11px] text-slate-700">
                        {networkInfo.bssid}
                      </span>
                    </div>

                    <div className="pt-2 flex items-center justify-between gap-2">
                      <span className="text-slate-500 shrink-0">Status:</span>
                      <span
                        className="font-extrabold text-[#0C44AC] text-[11px] text-right truncate"
                        title={routerSessionState === 'AUTHENTICATED' ? 'Router berhasil terhubung' : routerCapability.status}
                      >
                        {routerSessionState === 'AUTHENTICATED' ? 'Router berhasil terhubung' : routerCapability.status}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Label Section */}
              <div className="mt-5 mb-3 flex items-center justify-between">
                <span className="text-xs font-black text-white/90 uppercase tracking-wider">
                  Menu Utama
                </span>
                <span className="text-[11px] font-bold text-blue-200">
                  Pilih Layanan
                </span>
              </div>

              {/* Menu Utama (Grid 2 Kolom + 1 Tengah Sesuai Desain Asli) */}
              <div className="grid grid-cols-2 gap-3 sm:gap-3.5">
                
                {/* 👥 PERANGKAT */}
                <button
                  type="button"
                  onClick={() => handleMenuClick('PERANGKAT')}
                  className="min-h-[114px] p-3.5 rounded-2xl bg-white hover:bg-blue-50 active:scale-[0.98] text-[#08296B] shadow-md shadow-black/20 border-2 border-white/30 transition-all flex flex-col items-center justify-center text-center group cursor-pointer"
                >
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0C44AC] to-[#08296B] text-white flex items-center justify-center mb-2 shadow-xs group-hover:scale-105 transition-transform">
                    <Users className="w-6 h-6 stroke-[2.4]" />
                  </div>
                  <span className="text-xs sm:text-sm font-black tracking-tight leading-tight uppercase">
                    👥 PERANGKAT
                  </span>
                  <span className="text-[10px] font-bold text-blue-700 mt-1 bg-blue-100/80 px-2 py-0.5 rounded-full">
                    5 Terhubung
                  </span>
                </button>

                {/* 🔐 PENGATURAN WI-FI */}
                <button
                  type="button"
                  onClick={() => handleMenuClick('PENGATURAN WI-FI')}
                  className="min-h-[114px] p-3.5 rounded-2xl bg-white hover:bg-blue-50 active:scale-[0.98] text-[#08296B] shadow-md shadow-black/20 border-2 border-white/30 transition-all flex flex-col items-center justify-center text-center group cursor-pointer"
                >
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0C44AC] to-[#08296B] text-white flex items-center justify-center mb-2 shadow-xs group-hover:scale-105 transition-transform">
                    <Lock className="w-6 h-6 stroke-[2.4]" />
                  </div>
                  <span className="text-xs sm:text-sm font-black tracking-tight leading-tight uppercase">
                    🔐 PENGATURAN<br />WI-FI
                  </span>
                </button>

                {/* 🛡️ PERLINDUNGAN */}
                <button
                  type="button"
                  onClick={() => handleMenuClick('PERLINDUNGAN')}
                  className="min-h-[114px] p-3.5 rounded-2xl bg-white hover:bg-blue-50 active:scale-[0.98] text-[#08296B] shadow-md shadow-black/20 border-2 border-white/30 transition-all flex flex-col items-center justify-center text-center group cursor-pointer"
                >
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0C44AC] to-[#08296B] text-white flex items-center justify-center mb-2 shadow-xs group-hover:scale-105 transition-transform">
                    <ShieldCheck className="w-6 h-6 stroke-[2.4]" />
                  </div>
                  <span className="text-xs sm:text-sm font-black tracking-tight leading-tight uppercase">
                    🛡️ PERLINDUNGAN
                  </span>
                  <span className="text-[10px] font-bold text-emerald-800 mt-1 bg-emerald-100 px-2 py-0.5 rounded-full">
                    Aktif
                  </span>
                </button>

                {/* 📋 RIWAYAT */}
                <button
                  type="button"
                  onClick={() => handleMenuClick('RIWAYAT')}
                  className="min-h-[114px] p-3.5 rounded-2xl bg-white hover:bg-blue-50 active:scale-[0.98] text-[#08296B] shadow-md shadow-black/20 border-2 border-white/30 transition-all flex flex-col items-center justify-center text-center group cursor-pointer"
                >
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0C44AC] to-[#08296B] text-white flex items-center justify-center mb-2 shadow-xs group-hover:scale-105 transition-transform">
                    <ClipboardList className="w-6 h-6 stroke-[2.4]" />
                  </div>
                  <span className="text-xs sm:text-sm font-black tracking-tight leading-tight uppercase">
                    📋 RIWAYAT
                  </span>
                  <span className="text-[10px] font-bold text-blue-700 mt-1 bg-blue-100/80 px-2 py-0.5 rounded-full">
                    {historyLogs.length} Catatan
                  </span>
                </button>

                {/* ⚙️ PENGATURAN (TENGAH) */}
                <div className="col-span-2 flex justify-center">
                  <button
                    type="button"
                    onClick={() => handleMenuClick('PENGATURAN')}
                    className="w-[calc(50%-0.4375rem)] min-h-[114px] p-3.5 rounded-2xl bg-white hover:bg-blue-50 active:scale-[0.98] text-[#08296B] shadow-md shadow-black/20 border-2 border-white/30 transition-all flex flex-col items-center justify-center text-center group cursor-pointer"
                  >
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0C44AC] to-[#08296B] text-white flex items-center justify-center mb-2 shadow-xs group-hover:scale-105 transition-transform">
                      <Settings className="w-6 h-6 stroke-[2.4]" />
                    </div>
                    <span className="text-xs sm:text-sm font-black tracking-tight leading-tight uppercase">
                      ⚙️ PENGATURAN
                    </span>
                  </button>
                </div>

              </div>

              {/* 🚪 KELUAR */}
              <div className="mt-5 pt-4 border-t border-white/15">
                <button
                  type="button"
                  onClick={() => setShowLogoutModal(true)}
                  className="w-full h-13 rounded-2xl bg-white hover:bg-blue-50 active:bg-blue-100 text-[#08296B] font-black text-sm uppercase tracking-wider shadow-lg shadow-black/25 active:scale-[0.99] transition-all flex items-center justify-center gap-2 border-2 border-white cursor-pointer"
                >
                  <LogOut className="w-4 h-4 text-[#0C44AC] stroke-[2.5]" />
                  <span>🚪 KELUAR</span>
                </button>
              </div>

            </div>

            <div className="px-5 py-2.5 bg-[#051C4D] text-center border-t border-white/10">
              <p className="text-[10px] font-black text-blue-200 uppercase tracking-widest">
                R2 CONTROL WIFI · KONTROL AKTIF
              </p>
            </div>

          </div>
        )}

        {/* ========================================================
            HALAMAN TAHAP 7: ⚙️ PENGATURAN
           ======================================================== */}
        {currentPage === 'settings' && (
          <div className="bg-gradient-to-b from-[#0C44AC] via-[#0A3B96] to-[#08296B] rounded-3xl border-2 border-white/20 shadow-[0_25px_60px_-10px_rgba(0,0,0,0.5)] overflow-hidden transition-all text-white">
            
            <div className="h-2 w-full flex">
              <div className="w-2/5 bg-[#051C4D]" />
              <div className="w-1/5 bg-white" />
              <div className="w-2/5 bg-[#3B82F6]" />
            </div>

            <div className="p-5 sm:p-6">
              
              <div className="mb-4">
                <button
                  type="button"
                  onClick={() => setCurrentPage('dashboard')}
                  className="w-full h-12 rounded-2xl bg-white hover:bg-blue-50 active:bg-blue-100 text-[#08296B] font-black text-xs uppercase tracking-wider shadow-md shadow-black/20 active:scale-[0.99] transition-all flex items-center justify-center gap-2 border-2 border-white cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4 stroke-[3] text-[#0C44AC]" />
                  <span>← KEMBALI</span>
                </button>
              </div>

              <div className="flex items-center justify-between pb-3.5 border-b border-white/15">
                <div>
                  <h1 className="text-2xl sm:text-[26px] font-black text-white tracking-tight uppercase leading-none drop-shadow-sm flex items-center gap-2">
                    <span>⚙️</span>
                    <span>PENGATURAN</span>
                  </h1>
                  <p className="text-xs font-extrabold text-blue-100 tracking-wide mt-1.5 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span>Konfigurasi & Preferensi Sistem</span>
                  </p>
                </div>

                <div className="w-11 h-11 rounded-2xl bg-white p-1 shadow-md shadow-black/20 flex items-center justify-center shrink-0">
                  <div className="w-full h-full rounded-xl bg-[#0C44AC] flex items-center justify-center">
                    <Settings className="w-5 h-5 text-white stroke-[2.4]" />
                  </div>
                </div>
              </div>

              {settingsToast && (
                <div className="mt-3.5 p-3 rounded-xl bg-white text-[#08296B] text-xs font-black flex items-center justify-between shadow-lg shadow-black/20 animate-in fade-in duration-200">
                  <span>{settingsToast}</span>
                  <span className="text-[10px] text-[#0C44AC] uppercase font-black">Info</span>
                </div>
              )}

              <div className="space-y-3.5 mt-4">
                {/* 1. 👤 Akun */}
                <div className="bg-white rounded-2xl p-4 text-[#08296B] shadow-md shadow-black/20 border-2 border-white/40">
                  <div className="flex items-center gap-2.5 pb-2.5 border-b border-slate-100">
                    <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#0C44AC] flex items-center justify-center text-sm font-bold">
                      👤
                    </div>
                    <h3 className="text-sm font-black uppercase tracking-wide text-[#08296B]">
                      Akun
                    </h3>
                  </div>

                  <div className="divide-y divide-slate-100 pt-1 text-xs">
                    <div
                      onClick={() => triggerSettingFeedback('Status akun')}
                      className="py-2.5 flex items-center justify-between cursor-pointer hover:bg-slate-50/80 px-1 rounded-lg transition-colors"
                    >
                      <span className="font-extrabold text-slate-700">Status akun</span>
                      <span className="inline-flex items-center gap-1 font-black text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full text-[11px]">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                        Administrator Aktif
                      </span>
                    </div>

                    <div
                      onClick={() => triggerSettingFeedback('Perangkat aktif')}
                      className="py-2.5 flex items-center justify-between cursor-pointer hover:bg-slate-50/80 px-1 rounded-lg transition-colors"
                    >
                      <span className="font-extrabold text-slate-700">Perangkat aktif</span>
                      <span className="font-black text-[#0C44AC] bg-blue-50 border border-blue-100 px-2 py-0.5 rounded-full text-[11px]">
                        1 Sesi Login
                      </span>
                    </div>
                  </div>
                </div>

                {/* 2. 🔐 Keamanan */}
                <div className="bg-white rounded-2xl p-4 text-[#08296B] shadow-md shadow-black/20 border-2 border-white/40">
                  <div className="flex items-center gap-2.5 pb-2.5 border-b border-slate-100">
                    <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#0C44AC] flex items-center justify-center text-sm font-bold">
                      🔐
                    </div>
                    <h3 className="text-sm font-black uppercase tracking-wide text-[#08296B]">
                      Keamanan
                    </h3>
                  </div>

                  <div className="divide-y divide-slate-100 pt-1 text-xs">
                    <div
                      onClick={() => triggerSettingFeedback('Pemulihan akses')}
                      className="py-2.5 flex items-center justify-between cursor-pointer hover:bg-slate-50/80 px-1 rounded-lg transition-colors group"
                    >
                      <span className="font-extrabold text-slate-700">Pemulihan akses</span>
                      <div className="flex items-center gap-1 text-slate-400 group-hover:text-[#0C44AC]">
                        <span className="text-[11px] font-bold text-slate-500">Tersedia</span>
                        <ChevronRight className="w-4 h-4" />
                      </div>
                    </div>

                    <div
                      onClick={() => triggerSettingFeedback('Verifikasi keamanan')}
                      className="py-2.5 flex items-center justify-between cursor-pointer hover:bg-slate-50/80 px-1 rounded-lg transition-colors group"
                    >
                      <span className="font-extrabold text-slate-700">Verifikasi keamanan</span>
                      <div className="flex items-center gap-1 text-slate-400 group-hover:text-[#0C44AC]">
                        <span className="text-[11px] font-bold text-emerald-700">Terproteksi</span>
                        <ChevronRight className="w-4 h-4" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* 3. 🔔 Notifikasi */}
                <div className="bg-white rounded-2xl p-4 text-[#08296B] shadow-md shadow-black/20 border-2 border-white/40">
                  <div className="flex items-center gap-2.5 pb-2.5 border-b border-slate-100">
                    <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#0C44AC] flex items-center justify-center text-sm font-bold">
                      🔔
                    </div>
                    <h3 className="text-sm font-black uppercase tracking-wide text-[#08296B]">
                      Notifikasi
                    </h3>
                  </div>

                  <div className="divide-y divide-slate-100 pt-1 text-xs">
                    <div className="py-2.5 flex items-center justify-between">
                      <span className="font-extrabold text-slate-700">
                        Peringatan perangkat baru
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setNotifyNewDevice(!notifyNewDevice);
                          triggerSettingFeedback(
                            notifyNewDevice
                              ? 'Peringatan perangkat baru dinonaktifkan'
                              : 'Peringatan perangkat baru diaktifkan'
                          );
                        }}
                        className={`w-11 h-6 rounded-full transition-colors relative p-0.5 cursor-pointer ${
                          notifyNewDevice ? 'bg-[#0C44AC]' : 'bg-slate-300'
                        }`}
                      >
                        <div
                          className={`w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                            notifyNewDevice ? 'translate-x-5' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>

                    <div className="py-2.5 flex items-center justify-between">
                      <span className="font-extrabold text-slate-700">
                        Peringatan perangkat diblokir
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setNotifyBlockedDevice(!notifyBlockedDevice);
                          triggerSettingFeedback(
                            notifyBlockedDevice
                              ? 'Peringatan perangkat diblokir dinonaktifkan'
                              : 'Peringatan perangkat diblokir diaktifkan'
                          );
                        }}
                        className={`w-11 h-6 rounded-full transition-colors relative p-0.5 cursor-pointer ${
                          notifyBlockedDevice ? 'bg-[#0C44AC]' : 'bg-slate-300'
                        }`}
                      >
                        <div
                          className={`w-5 h-5 rounded-full bg-white shadow-xs transition-transform ${
                            notifyBlockedDevice ? 'translate-x-5' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                </div>

                {/* 4. ℹ️ Tentang */}
                <div className="bg-white rounded-2xl p-4 text-[#08296B] shadow-md shadow-black/20 border-2 border-white/40">
                  <div className="flex items-center gap-2.5 pb-2.5 border-b border-slate-100">
                    <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#0C44AC] flex items-center justify-center text-sm font-bold">
                      ℹ️
                    </div>
                    <h3 className="text-sm font-black uppercase tracking-wide text-[#08296B]">
                      Tentang
                    </h3>
                  </div>

                  <div className="divide-y divide-slate-100 pt-1 text-xs">
                    <div className="py-2.5 flex items-center justify-between">
                      <span className="font-extrabold text-slate-700">R2 Control WiFi</span>
                      <span className="font-mono font-bold text-slate-500">Wi-Fi Gateway OS</span>
                    </div>

                    <div className="py-2.5 flex items-center justify-between">
                      <span className="font-extrabold text-slate-700">Versi aplikasi</span>
                      <span className="font-mono font-black text-[#0C44AC] bg-blue-50 px-2 py-0.5 rounded-full text-[11px]">
                        v2.4.0 (2026)
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-white/15">
                <button
                  type="button"
                  onClick={() => setCurrentPage('dashboard')}
                  className="w-full h-12 rounded-2xl bg-white hover:bg-blue-50 active:bg-blue-100 text-[#08296B] font-black text-xs uppercase tracking-wider shadow-lg shadow-black/25 active:scale-[0.99] transition-all flex items-center justify-center gap-2 border-2 border-white cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4 stroke-[3] text-[#0C44AC]" />
                  <span>← KEMBALI</span>
                </button>
              </div>

            </div>

            <div className="px-5 py-2.5 bg-[#051C4D] text-center border-t border-white/10">
              <p className="text-[10px] font-black text-blue-200 uppercase tracking-widest">
                R2 CONTROL WIFI · PENGATURAN
              </p>
            </div>

          </div>
        )}

        {/* ========================================================
            HALAMAN TAHAP 6: 📋 RIWAYAT
           ======================================================== */}
        {currentPage === 'history' && (
          <div className="bg-gradient-to-b from-[#0C44AC] via-[#0A3B96] to-[#08296B] rounded-3xl border-2 border-white/20 shadow-[0_25px_60px_-10px_rgba(0,0,0,0.5)] overflow-hidden transition-all text-white">
            
            <div className="h-2 w-full flex">
              <div className="w-2/5 bg-[#051C4D]" />
              <div className="w-1/5 bg-white" />
              <div className="w-2/5 bg-[#3B82F6]" />
            </div>

            <div className="p-5 sm:p-6">
              
              <div className="mb-4">
                <button
                  type="button"
                  onClick={() => setCurrentPage('dashboard')}
                  className="w-full h-12 rounded-2xl bg-white hover:bg-blue-50 active:bg-blue-100 text-[#08296B] font-black text-xs uppercase tracking-wider shadow-md shadow-black/20 active:scale-[0.99] transition-all flex items-center justify-center gap-2 border-2 border-white cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4 stroke-[3] text-[#0C44AC]" />
                  <span>← KEMBALI KE DASHBOARD</span>
                </button>
              </div>

              <div className="flex items-center justify-between pb-3.5 border-b border-white/15">
                <div>
                  <h1 className="text-2xl sm:text-[26px] font-black text-white tracking-tight uppercase leading-none drop-shadow-sm flex items-center gap-2">
                    <span>📋</span>
                    <span>RIWAYAT</span>
                  </h1>
                  <p className="text-xs font-extrabold text-blue-100 tracking-wide mt-1.5 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span>Catatan Aktivitas Jaringan</span>
                  </p>
                </div>

                <div className="w-11 h-11 rounded-2xl bg-white p-1 shadow-md shadow-black/20 flex items-center justify-center shrink-0">
                  <div className="w-full h-full rounded-xl bg-[#0C44AC] flex items-center justify-center">
                    <History className="w-5 h-5 text-white stroke-[2.4]" />
                  </div>
                </div>
              </div>

              <div className="mt-4 mb-3 flex items-center justify-between">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 backdrop-blur-md border border-white/20">
                  <Clock className="w-3.5 h-3.5 text-blue-200" />
                  <span className="text-xs font-black uppercase tracking-wider text-white">
                    Hari ini
                  </span>
                </div>

                <span className="text-[11px] font-bold text-blue-200">
                  {historyLogs.length} Catatan
                </span>
              </div>

              <div className="space-y-3">
                {historyLogs.map((log) => (
                  <div
                    key={log.id}
                    className="p-4 rounded-2xl bg-white text-[#08296B] shadow-md shadow-black/20 border-2 border-white/40 flex items-start gap-3.5 transition-all hover:shadow-lg"
                  >
                    <div className="flex flex-col items-center shrink-0">
                      <div
                        className={`w-11 h-11 rounded-xl flex items-center justify-center text-lg font-bold shadow-xs ${
                          log.type === 'success'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : log.type === 'danger'
                            ? 'bg-red-50 text-red-700 border border-red-200'
                            : log.type === 'auth'
                            ? 'bg-blue-50 text-[#0C44AC] border border-blue-200'
                            : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                        }`}
                      >
                        <span>{log.badgeEmoji}</span>
                      </div>
                      <span className="font-mono text-[11px] font-black text-slate-500 mt-1.5">
                        {log.time}
                      </span>
                    </div>

                    <div className="flex-1 min-w-0 pt-0.5">
                      <div className="flex items-center justify-between gap-2">
                        <h3 className="text-base sm:text-[17px] font-black tracking-tight text-[#08296B] leading-snug truncate">
                          {log.title}
                        </h3>
                        <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-slate-100 text-slate-600 shrink-0">
                          {log.time}
                        </span>
                      </div>

                      <p
                        className={`text-xs sm:text-sm font-extrabold mt-1 ${
                          log.type === 'danger'
                            ? 'text-red-600'
                            : log.type === 'success'
                            ? 'text-emerald-700'
                            : 'text-blue-700'
                        }`}
                      >
                        {log.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-5 pt-4 border-t border-white/15">
                <button
                  type="button"
                  onClick={() => setCurrentPage('dashboard')}
                  className="w-full h-12 rounded-2xl bg-white/15 hover:bg-white/25 active:bg-white/30 text-white font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 border border-white/30 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4 stroke-[2.5]" />
                  <span>← KEMBALI KE DASHBOARD</span>
                </button>
              </div>

            </div>

            <div className="px-5 py-2.5 bg-[#051C4D] text-center border-t border-white/10">
              <p className="text-[10px] font-black text-blue-200 uppercase tracking-widest">
                R2 CONTROL WIFI · LOG RIWAYAT
              </p>
            </div>

          </div>
        )}

        {/* ========================================================
            HALAMAN TAHAP 5: 🛡️ PERLINDUNGAN
           ======================================================== */}
        {currentPage === 'protection' && (
          <div className="bg-gradient-to-b from-[#0C44AC] via-[#0A3B96] to-[#08296B] rounded-3xl border-2 border-white/20 shadow-[0_25px_60px_-10px_rgba(0,0,0,0.5)] overflow-hidden transition-all text-white">
            
            <div className="h-2 w-full flex">
              <div className="w-2/5 bg-[#051C4D]" />
              <div className="w-1/5 bg-white" />
              <div className="w-2/5 bg-[#3B82F6]" />
            </div>

            <div className="p-5 sm:p-6">
              
              <div className="mb-4">
                <button
                  type="button"
                  onClick={() => setCurrentPage('dashboard')}
                  className="w-full h-12 rounded-2xl bg-white hover:bg-blue-50 active:bg-blue-100 text-[#08296B] font-black text-xs uppercase tracking-wider shadow-md shadow-black/20 active:scale-[0.99] transition-all flex items-center justify-center gap-2 border-2 border-white cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4 stroke-[3] text-[#0C44AC]" />
                  <span>← KEMBALI KE DASHBOARD</span>
                </button>
              </div>

              <div className="flex items-center justify-between pb-3.5 border-b border-white/15">
                <div>
                  <h1 className="text-2xl sm:text-[26px] font-black text-white tracking-tight uppercase leading-none drop-shadow-sm flex items-center gap-2">
                    <span>🛡️</span>
                    <span>PERLINDUNGAN</span>
                  </h1>
                  <p className="text-xs font-extrabold text-blue-100 tracking-wide mt-1.5 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span>Sistem Keamanan Firewall Aktif</span>
                  </p>
                </div>

                <div className="w-11 h-11 rounded-2xl bg-white p-1 shadow-md shadow-black/20 flex items-center justify-center shrink-0">
                  <div className="w-full h-full rounded-xl bg-[#0C44AC] flex items-center justify-center">
                    <ShieldCheck className="w-6 h-6 text-white stroke-[2.4]" />
                  </div>
                </div>
              </div>

              {protectionToast && (
                <div className="mt-3.5 p-3 rounded-xl bg-white text-[#08296B] text-xs font-black flex items-center justify-between shadow-lg shadow-black/20 animate-in fade-in duration-200">
                  <span>{protectionToast}</span>
                  <span className="text-[10px] text-[#0C44AC] uppercase font-black">Status</span>
                </div>
              )}

              <div className="mt-4 p-5 rounded-2xl bg-white text-[#08296B] shadow-md shadow-black/20 border-2 border-white/40 text-center">
                <span className="text-xs font-black uppercase tracking-wider text-slate-500 block mb-1">
                  Status Keamanan
                </span>
                
                <h2 className="text-lg sm:text-xl font-black text-[#08296B] tracking-tight uppercase">
                  PERLINDUNGAN WI-FI
                </h2>

                <div className="my-3 flex justify-center">
                  <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-100 border border-emerald-300 text-emerald-800 shadow-xs">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                    <span className="text-sm font-black tracking-wider uppercase">
                      🟢 AKTIF
                    </span>
                  </div>
                </div>

                <p className="text-xs font-bold text-slate-600">
                  Wi-Fi sedang dilindungi
                </p>
              </div>

              <div className="my-5 flex items-center gap-3">
                <div className="flex-1 h-0.5 bg-white/20" />
                <span className="text-[11px] font-black uppercase tracking-widest text-blue-200">
                  PENGAWASAN AKSES
                </span>
                <div className="flex-1 h-0.5 bg-white/20" />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between pl-1">
                  <span className="text-xs font-black text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-amber-400 stroke-[2.5]" />
                    <span>⚠️ PERANGKAT TIDAK DIKENAL</span>
                  </span>
                  {unknownDevice.status === 'pending' && (
                    <span className="text-[10px] font-black bg-amber-400 text-slate-950 px-2 py-0.5 rounded-full">
                      Butuh Tindakan
                    </span>
                  )}
                </div>

                {unknownDevice.status === 'pending' ? (
                  <div className="p-4 sm:p-5 rounded-2xl bg-white text-[#08296B] shadow-md shadow-black/20 border-2 border-white/40">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 text-white flex items-center justify-center shadow-xs shrink-0">
                          <Smartphone className="w-6 h-6 stroke-[2.4]" />
                        </div>
                        <div>
                          <h3 className="text-base sm:text-lg font-black tracking-tight text-[#08296B] leading-snug flex items-center gap-1.5">
                            <span>{unknownDevice.emoji}</span>
                            <span>{unknownDevice.name}</span>
                          </h3>
                          <div className="mt-1 text-xs font-semibold text-slate-500 flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5 text-slate-400" />
                            <span>Pertama terlihat:</span>
                            <span className="font-mono font-bold text-slate-800">
                              {unknownDevice.firstSeen}
                            </span>
                          </div>
                        </div>
                      </div>

                      <span className="text-[10px] font-extrabold uppercase px-2 py-1 rounded bg-amber-100 text-amber-800">
                        Belum Diizinkan
                      </span>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2.5">
                      <button
                        type="button"
                        onClick={handleAllowDevice}
                        className="h-11 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-black text-xs uppercase tracking-wider shadow-sm active:scale-[0.98] transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <Check className="w-4 h-4 stroke-[3]" />
                        <span>[ IZINKAN ]</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleBlockDevice}
                        className="h-11 rounded-xl bg-red-600 hover:bg-red-700 active:bg-red-800 text-white font-black text-xs uppercase tracking-wider shadow-sm active:scale-[0.98] transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <Ban className="w-4 h-4 stroke-[3]" />
                        <span>[ BLOKIR ]</span>
                      </button>
                    </div>
                  </div>
                ) : unknownDevice.status === 'allowed' ? (
                  <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 text-center">
                    <p className="text-xs font-bold text-emerald-300 flex items-center justify-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      Redmi Note 13 telah diizinkan.
                    </p>
                    <button
                      type="button"
                      onClick={() => setUnknownDevice((prev) => ({ ...prev, status: 'pending' }))}
                      className="mt-1 text-[11px] font-bold text-blue-200 underline"
                    >
                      Reset Uji Coba
                    </button>
                  </div>
                ) : (
                  <div className="p-3.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 text-center text-xs font-bold text-red-200">
                    Redmi Note 13 telah dipindahkan ke daftar blokir di bawah.
                  </div>
                )}
              </div>

              <div className="my-5 flex items-center gap-3">
                <div className="flex-1 h-0.5 bg-white/20" />
                <span className="text-[11px] font-black uppercase tracking-widest text-blue-200">
                  DAFTAR HITAM
                </span>
                <div className="flex-1 h-0.5 bg-white/20" />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between pl-1">
                  <span className="text-xs font-black text-red-300 uppercase tracking-wider flex items-center gap-1.5">
                    <span>🔴</span>
                    <span>PERANGKAT DIBLOKIR</span>
                  </span>
                  <span className="text-[10px] font-black bg-red-500/30 text-white px-2 py-0.5 rounded-full border border-red-400/40">
                    {blockedDevices.length} Terblokir
                  </span>
                </div>

                <div className="space-y-2.5">
                  {blockedDevices.map((blocked) => (
                    <div
                      key={blocked.id}
                      className="p-4 rounded-2xl bg-white text-[#08296B] shadow-md shadow-black/20 border-2 border-white/40 flex items-center justify-between transition-all"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-red-600 to-[#08296B] text-white flex items-center justify-center shrink-0 shadow-xs">
                          <Ban className="w-6 h-6 stroke-[2.4]" />
                        </div>
                        <div>
                          <h3 className="text-base sm:text-lg font-black tracking-tight text-[#08296B] leading-snug flex items-center gap-1.5">
                            <span>{blocked.emoji}</span>
                            <span>{blocked.name}</span>
                          </h3>
                          <p className="text-xs font-extrabold text-red-600 mt-0.5 flex items-center gap-1">
                            <span className="w-2 h-2 rounded-full bg-red-600" />
                            <span>{blocked.reason}</span>
                          </p>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleUnblockDevice(blocked.id, blocked.name)}
                        className="px-2.5 py-1.5 rounded-xl border border-slate-300 hover:border-[#0C44AC] text-slate-700 hover:text-[#0C44AC] text-[11px] font-black uppercase tracking-wide transition-colors shrink-0 cursor-pointer"
                      >
                        Buka Blokir
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-white/15">
                <button
                  type="button"
                  onClick={() => setCurrentPage('dashboard')}
                  className="w-full h-12 rounded-2xl bg-white/15 hover:bg-white/25 active:bg-white/30 text-white font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 border border-white/30 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4 stroke-[2.5]" />
                  <span>← KEMBALI KE DASHBOARD</span>
                </button>
              </div>

            </div>

            <div className="px-5 py-2.5 bg-[#051C4D] text-center border-t border-white/10">
              <p className="text-[10px] font-black text-blue-200 uppercase tracking-widest">
                R2 CONTROL WIFI · SISTEM PERLINDUNGAN
              </p>
            </div>

          </div>
        )}

        {/* ========================================================
            HALAMAN TAHAP 4: PENGATURAN WI-FI
           ======================================================== */}
        {currentPage === 'wifi_settings' && (
          <div className="bg-gradient-to-b from-[#0C44AC] via-[#0A3B96] to-[#08296B] rounded-3xl border-2 border-white/20 shadow-[0_25px_60px_-10px_rgba(0,0,0,0.5)] overflow-hidden transition-all text-white">
            
            <div className="h-2 w-full flex">
              <div className="w-2/5 bg-[#051C4D]" />
              <div className="w-1/5 bg-white" />
              <div className="w-2/5 bg-[#3B82F6]" />
            </div>

            <div className="p-5 sm:p-6">
              
              <div className="mb-4">
                <button
                  type="button"
                  onClick={() => setCurrentPage('dashboard')}
                  className="w-full h-12 rounded-2xl bg-white hover:bg-blue-50 active:bg-blue-100 text-[#08296B] font-black text-xs uppercase tracking-wider shadow-md shadow-black/20 active:scale-[0.99] transition-all flex items-center justify-center gap-2 border-2 border-white cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4 stroke-[3] text-[#0C44AC]" />
                  <span>← KEMBALI KE DASHBOARD</span>
                </button>
              </div>

              <div className="flex items-center justify-between pb-3.5 border-b border-white/15">
                <div>
                  <h1 className="text-2xl sm:text-[26px] font-black text-white tracking-tight uppercase leading-none drop-shadow-sm">
                    PENGATURAN WI-FI
                  </h1>
                  <p className="text-xs font-extrabold text-blue-100 tracking-wide mt-1.5 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span>Konfigurasi Akses Jaringan</span>
                  </p>
                </div>

                <div className="w-11 h-11 rounded-2xl bg-white p-1 shadow-md shadow-black/20 flex items-center justify-center shrink-0">
                  <div className="w-full h-full rounded-xl bg-[#0C44AC] flex items-center justify-center">
                    <Lock className="w-5 h-5 text-white stroke-[2.4]" />
                  </div>
                </div>
              </div>

              {(passwordSuccessMessage || ssidSuccessMessage) && (
                <div className="mt-3.5 p-3 rounded-xl bg-emerald-500 text-white text-xs font-black flex items-center gap-2 shadow-md">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{passwordSuccessMessage || ssidSuccessMessage}</span>
                </div>
              )}

              <div className="mt-4 space-y-4">
                <div>
                  <label className="block text-xs font-black uppercase tracking-wider text-blue-100 mb-1.5 pl-0.5">
                    Nama Wi-Fi
                  </label>

                  {isEditingSsid ? (
                    <div className="space-y-2 p-3 rounded-2xl bg-white text-[#08296B] shadow-md border-2 border-white/40">
                      <input
                        type="text"
                        value={tempSsid}
                        onChange={(e) => setTempSsid(e.target.value)}
                        placeholder="Masukkan nama Wi-Fi baru"
                        className="w-full h-11 px-3.5 rounded-xl bg-slate-50 border-2 border-slate-200 font-black text-sm text-slate-900 focus:border-[#0C44AC] outline-none"
                      />
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={handleSaveSsid}
                          className="flex-1 h-9 rounded-lg bg-[#0C44AC] text-white font-black text-xs uppercase"
                        >
                          Simpan Nama
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setTempSsid(wifiSsid);
                            setIsEditingSsid(false);
                          }}
                          className="px-3 h-9 rounded-lg bg-slate-100 text-slate-700 font-bold text-xs"
                        >
                          Batal
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="w-full h-14 px-4 rounded-2xl bg-white text-[#08296B] font-black text-base shadow-md shadow-black/20 border-2 border-white/40 flex items-center gap-2.5">
                      <span className="text-xl">🛜</span>
                      <span className="truncate">{wifiSsid}</span>
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-black uppercase tracking-wider text-blue-100 mb-1.5 pl-0.5">
                    Password Wi-Fi
                  </label>

                  <div className="w-full h-14 px-4 rounded-2xl bg-white text-[#08296B] font-black text-base shadow-md shadow-black/20 border-2 border-white/40 flex items-center justify-between">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className="text-lg">🔒</span>
                      <span className="font-mono text-sm tracking-wider truncate text-slate-800">
                        {showWifiPassword ? wifiPassword : '••••••••••••••'}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => setShowWifiPassword(!showWifiPassword)}
                      aria-label={showWifiPassword ? 'Sembunyikan password' : 'Lihat password'}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-[#0C44AC] transition-colors"
                    >
                      {showWifiPassword ? (
                        <EyeOff className="w-5 h-5 stroke-[2.2]" />
                      ) : (
                        <Eye className="w-5 h-5 stroke-[2.2]" />
                      )}
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setTempSsid(wifiSsid);
                      setIsEditingSsid(!isEditingSsid);
                      setShowChangePasswordForm(false);
                    }}
                    className="h-12 px-3 rounded-2xl bg-white hover:bg-blue-50 active:scale-[0.98] text-[#08296B] font-black text-xs uppercase tracking-wide shadow-md shadow-black/15 border-2 border-white/30 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <span>✏️</span>
                    <span>GANTI NAMA WI-FI</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setShowChangePasswordForm(!showChangePasswordForm);
                      setIsEditingSsid(false);
                      setPasswordFormError('');
                    }}
                    className="h-12 px-3 rounded-2xl bg-white hover:bg-blue-50 active:scale-[0.98] text-[#08296B] font-black text-xs uppercase tracking-wide shadow-md shadow-black/15 border-2 border-white/30 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <span>🔑</span>
                    <span>GANTI PASSWORD</span>
                  </button>
                </div>

                {showChangePasswordForm && (
                  <form
                    onSubmit={handleSavePassword}
                    className="p-4 sm:p-5 rounded-2xl bg-white text-[#08296B] shadow-xl shadow-black/25 border-2 border-white/40 space-y-3.5 animate-in fade-in zoom-in-95 duration-200 mt-2"
                  >
                    <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                      <span className="text-xs font-black uppercase text-[#08296B] flex items-center gap-1.5">
                        <KeyRound className="w-4 h-4 text-[#0C44AC]" />
                        Ubah Password Wi-Fi
                      </span>
                      <button
                        type="button"
                        onClick={() => setShowChangePasswordForm(false)}
                        className="text-[11px] font-bold text-slate-400 hover:text-slate-600"
                      >
                        Batal
                      </button>
                    </div>

                    {passwordFormError && (
                      <div className="p-2.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs font-bold flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                        <span>{passwordFormError}</span>
                      </div>
                    )}

                    <div>
                      <label className="block text-xs font-black uppercase tracking-wide text-slate-700 mb-1 pl-0.5">
                        Password Baru
                      </label>
                      <div className="relative">
                        <input
                          type={showNewPassword ? 'text' : 'password'}
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                          placeholder="Masukkan password baru"
                          className="w-full h-12 pl-3.5 pr-11 rounded-xl bg-slate-50 border-2 border-slate-200 font-bold text-sm text-slate-900 focus:border-[#0C44AC] outline-none transition-colors"
                        />
                        <button
                          type="button"
                          onClick={() => setShowNewPassword(!showNewPassword)}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1.5 text-slate-400 hover:text-[#0C44AC]"
                        >
                          {showNewPassword ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-black uppercase tracking-wide text-slate-700 mb-1 pl-0.5">
                        Konfirmasi Password
                      </label>
                      <div className="relative">
                        <input
                          type={showConfirmPassword ? 'text' : 'password'}
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          placeholder="Ulangi password baru"
                          className="w-full h-12 pl-3.5 pr-11 rounded-xl bg-slate-50 border-2 border-slate-200 font-bold text-sm text-slate-900 focus:border-[#0C44AC] outline-none transition-colors"
                        />
                        <button
                          type="button"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1.5 text-slate-400 hover:text-[#0C44AC]"
                        >
                          {showConfirmPassword ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    </div>

                    <div className="pt-1">
                      <button
                        type="submit"
                        className="w-full h-13 rounded-xl bg-[#0C44AC] hover:bg-[#0A3B96] active:bg-[#08296B] text-white font-black text-sm uppercase tracking-wider shadow-md shadow-[#0C44AC]/30 active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
                      >
                        [ SIMPAN PERUBAHAN ]
                      </button>
                    </div>

                    <p className="text-[11px] font-semibold text-slate-500 text-center italic pt-1">
                      "Perubahan akan diterapkan pada Wi-Fi yang terhubung."
                    </p>
                  </form>
                )}

              </div>

              <div className="mt-5 pt-4 border-t border-white/15">
                <button
                  type="button"
                  onClick={() => setCurrentPage('dashboard')}
                  className="w-full h-12 rounded-2xl bg-white/15 hover:bg-white/25 active:bg-white/30 text-white font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 border border-white/30 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4 stroke-[2.5]" />
                  <span>← KEMBALI KE DASHBOARD</span>
                </button>
              </div>

            </div>

            <div className="px-5 py-2.5 bg-[#051C4D] text-center border-t border-white/10">
              <p className="text-[10px] font-black text-blue-200 uppercase tracking-widest">
                R2 CONTROL WIFI · PENGATURAN WI-FI
              </p>
            </div>

          </div>
        )}

        {/* ========================================================
            HALAMAN TAHAP 3: PERANGKAT
           ======================================================== */}
        {currentPage === 'devices' && (
          <div className="bg-gradient-to-b from-[#0C44AC] via-[#0A3B96] to-[#08296B] rounded-3xl border-2 border-white/20 shadow-[0_25px_60px_-10px_rgba(0,0,0,0.5)] overflow-hidden transition-all text-white">
            
            <div className="h-2 w-full flex">
              <div className="w-2/5 bg-[#051C4D]" />
              <div className="w-1/5 bg-white" />
              <div className="w-2/5 bg-[#3B82F6]" />
            </div>

            <div className="p-5 sm:p-6">
              
              <div className="mb-4">
                <button
                  type="button"
                  onClick={() => setCurrentPage('dashboard')}
                  className="w-full h-12 rounded-2xl bg-white hover:bg-blue-50 active:bg-blue-100 text-[#08296B] font-black text-xs uppercase tracking-wider shadow-md shadow-black/20 active:scale-[0.99] transition-all flex items-center justify-center gap-2 border-2 border-white cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4 stroke-[3] text-[#0C44AC]" />
                  <span>← KEMBALI KE DASHBOARD</span>
                </button>
              </div>

              <div className="flex items-center justify-between pb-3.5 border-b border-white/15">
                <div>
                  <h1 className="text-2xl sm:text-[26px] font-black text-white tracking-tight uppercase leading-none drop-shadow-sm">
                    PERANGKAT
                  </h1>
                  <p className="text-xs sm:text-sm font-extrabold text-blue-100 tracking-wide mt-1.5 flex items-center gap-1.5">
                    <span>Perangkat Terhubung — {devices.length || 5}</span>
                  </p>
                </div>

                <button
                  type="button"
                  onClick={loadDevices}
                  title="Pindai Ulang Perangkat dari Router"
                  className="w-11 h-11 rounded-2xl bg-white p-1 shadow-md shadow-black/20 flex items-center justify-center shrink-0 hover:bg-blue-50 transition-colors"
                >
                  <div className="w-full h-full rounded-xl bg-[#0C44AC] flex items-center justify-center">
                    <RotateCw
                      className={`w-5 h-5 text-white stroke-[2.4] ${
                        isFetchingDevices ? 'animate-spin' : ''
                      }`}
                    />
                  </div>
                </button>
              </div>

              <div className="mt-3.5 mb-3 px-3 py-1.5 rounded-xl bg-white/10 backdrop-blur-md border border-white/15 flex items-center justify-between text-[11px] font-bold text-blue-100">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  Router Gateway: {networkInfo.gatewayIp}
                </span>
                <span className="text-[10px] text-blue-200 uppercase tracking-wider">
                  Live Router DHCP Ready
                </span>
              </div>

              <div className="space-y-3 mt-3">
                {devices.map((device) => (
                  <div
                    key={device.id}
                    className="p-4 rounded-2xl bg-white text-[#08296B] shadow-md shadow-black/20 border-2 border-white/40 flex items-center justify-between transition-all"
                  >
                    <div className="flex items-center gap-3.5">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0C44AC] to-[#08296B] text-white flex items-center justify-center shrink-0 shadow-sm">
                        {device.type === 'phone' && (
                          <Smartphone className="w-6 h-6 stroke-[2.4]" />
                        )}
                        {device.type === 'tv' && (
                          <Tv className="w-6 h-6 stroke-[2.4]" />
                        )}
                        {device.type === 'laptop' && (
                          <Laptop className="w-6 h-6 stroke-[2.4]" />
                        )}
                      </div>

                      <div>
                        <h3 className="text-base sm:text-lg font-black tracking-tight text-[#08296B] leading-snug flex items-center gap-1.5">
                          <span>{device.emoji}</span>
                          <span>{device.name}</span>
                        </h3>

                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                          <span className="text-xs font-black text-emerald-600">
                            🟢 Terhubung
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="shrink-0 text-right">
                      {device.isTrusted ? (
                        <div className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-black tracking-wide">
                          <span>✅</span>
                          <span>Dipercaya</span>
                        </div>
                      ) : (
                        <div className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-black tracking-wide">
                          <span>❓</span>
                          <span>Tidak dikenal</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-5 pt-4 border-t border-white/15">
                <button
                  type="button"
                  onClick={() => setCurrentPage('dashboard')}
                  className="w-full h-12 rounded-2xl bg-white/15 hover:bg-white/25 active:bg-white/30 text-white font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 border border-white/30 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4 stroke-[2.5]" />
                  <span>← KEMBALI KE DASHBOARD</span>
                </button>
              </div>

            </div>

            <div className="px-5 py-2.5 bg-[#051C4D] text-center border-t border-white/10">
              <p className="text-[10px] font-black text-blue-200 uppercase tracking-widest">
                R2 CONTROL WIFI · KONTROL PERANGKAT
              </p>
            </div>

          </div>
        )}

        {/* ========================================================
            HALAMAN: HUBUNGKAN ROUTER (ALUR AUTENTIKASI BARU)
           ======================================================== */}
        {currentPage === 'login' && (
          <div className="bg-gradient-to-b from-[#0C44AC] via-[#0A3B96] to-[#08296B] rounded-3xl border-2 border-white/20 shadow-[0_25px_60px_-10px_rgba(0,0,0,0.5)] overflow-hidden text-white">
            
            <div className="h-2 w-full flex">
              <div className="w-2/5 bg-[#051C4D]" />
              <div className="w-1/5 bg-white" />
              <div className="w-2/5 bg-[#3B82F6]" />
            </div>

            <div className="p-6 sm:p-8">
              <div className="text-center">
                <h1 className="text-2xl sm:text-[26px] font-black text-white tracking-tight leading-none uppercase">
                  R2 CONTROL WIFI
                </h1>
                <div className="w-12 h-1 bg-white mx-auto mt-2 rounded-full" />

                <div className="my-5 flex justify-center">
                  <div className="w-20 h-20 rounded-2xl bg-white p-1.5 shadow-lg shadow-black/25 flex items-center justify-center">
                    <div className="w-full h-full rounded-xl bg-[#0C44AC] flex items-center justify-center">
                      <Wifi className="w-9 h-9 text-white stroke-[2.4]" />
                    </div>
                  </div>
                </div>

                <h2 className="text-base font-extrabold tracking-wider text-white uppercase">
                  HUBUNGKAN ROUTER
                </h2>
              </div>

              {/* KONDISI 1: Terhubung ke Wi-Fi lain (Bukan Wi-Fi rumah terdaftar) */}
              {networkMatch === 'DIFFERENT_WIFI' && (
                <div className="mt-5 p-5 rounded-2xl bg-white text-[#08296B] shadow-lg border-2 border-white/40 text-center animate-in fade-in duration-200">
                  <div className="w-12 h-12 rounded-xl bg-red-100 text-red-600 mx-auto flex items-center justify-center mb-2.5">
                    <WifiOff className="w-6 h-6 stroke-[2.5]" />
                  </div>
                  <h3 className="text-sm font-black text-red-600 uppercase tracking-tight">
                    🔴 Router rumah tidak tersedia
                  </h3>
                  <p className="text-xs font-bold text-slate-600 mt-2 leading-relaxed">
                    Hubungkan perangkat ke Wi-Fi rumah untuk mengontrol router.
                  </p>
                </div>
              )}

              {/* KONDISI 2: Sesi Kedaluwarsa */}
              {routerSessionState === 'SESSION_EXPIRED' && !showAuthForm && (
                <div className="mt-5 p-5 rounded-2xl bg-white text-[#08296B] shadow-lg border-2 border-white/40 text-center animate-in fade-in duration-200">
                  <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-700 mx-auto flex items-center justify-center mb-2.5">
                    <AlertTriangle className="w-6 h-6 stroke-[2.5]" />
                  </div>
                  <h3 className="text-sm font-black text-amber-800 uppercase tracking-tight">
                    Sesi router telah berakhir.
                  </h3>
                  <p className="text-xs font-bold text-slate-500 mt-1 mb-4">
                    Kredensial perlu diverifikasi kembali ke router rumah.
                  </p>
                  <button
                    type="button"
                    onClick={() => setShowAuthForm(true)}
                    className="w-full h-13 rounded-xl bg-[#0C44AC] hover:bg-[#0A3B96] active:bg-[#08296B] text-white font-black text-xs uppercase tracking-wider shadow-md shadow-[#0C44AC]/25 cursor-pointer"
                  >
                    [ HUBUNGKAN KEMBALI ]
                  </button>
                </div>
              )}

              {/* KONDISI 3: Router Sudah Terhubung */}
              {routerSessionState === 'AUTHENTICATED' && !showAuthForm && (
                <div className="mt-5 p-5 rounded-2xl bg-white text-[#08296B] shadow-lg border-2 border-white/40 text-center animate-in fade-in duration-200">
                  <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-700 mx-auto flex items-center justify-center mb-2.5">
                    <CheckCircle2 className="w-6 h-6 stroke-[2.5]" />
                  </div>
                  <h3 className="text-sm font-black text-emerald-800 uppercase tracking-tight">
                    🟢 ROUTER TERHUBUNG
                  </h3>
                  <p className="text-xs font-bold text-slate-600 mt-1.5 mb-4 leading-relaxed">
                    Router rumah Anda sudah terhubung dan siap dikontrol.
                  </p>
                  <button
                    type="button"
                    onClick={() => setCurrentPage('dashboard')}
                    className="w-full h-13 rounded-xl bg-[#0C44AC] hover:bg-[#0A3B96] active:bg-[#08296B] text-white font-black text-xs uppercase tracking-wider shadow-md shadow-[#0C44AC]/25 cursor-pointer"
                  >
                    [ BUKA DASHBOARD ]
                  </button>
                </div>
              )}

              {/* KONDISI 4: Router Baru Terdeteksi (Belum Dihubungkan) - Tahap Pertama Kali */}
              {networkMatch !== 'DIFFERENT_WIFI' &&
                routerSessionState !== 'AUTHENTICATED' &&
                !showAuthForm && (
                  <div className="mt-5 p-5 rounded-2xl bg-white text-[#08296B] shadow-lg border-2 border-white/40 text-center animate-in fade-in duration-200">
                    <div className="w-12 h-12 rounded-xl bg-blue-50 text-[#0C44AC] mx-auto flex items-center justify-center mb-3">
                      <Radio className="w-6 h-6 stroke-[2.5]" />
                    </div>

                    <h3 className="text-sm font-black uppercase tracking-wider text-[#08296B] mb-2 flex items-center justify-center gap-1.5">
                      <span>📡</span>
                      <span>ROUTER DITEMUKAN</span>
                    </h3>

                    <div className="space-y-1.5 text-xs font-bold text-slate-600 my-3 py-2.5 border-y border-slate-100">
                      <div className="flex justify-between">
                        <span className="text-slate-500">Wi-Fi:</span>
                        <span className="font-extrabold text-[#08296B]">
                          {networkInfo.ssid !== 'Tidak tersedia' ? networkInfo.ssid : 'Wi-Fi Rumah'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Gateway:</span>
                        <span className="font-mono font-black text-[#0C44AC]">
                          {networkInfo.gatewayIp}
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setShowAuthForm(true)}
                      className="w-full h-13 rounded-xl bg-[#0C44AC] hover:bg-[#0A3B96] active:bg-[#08296B] text-white font-black text-xs uppercase tracking-wider shadow-md shadow-[#0C44AC]/25 cursor-pointer"
                    >
                      [ HUBUNGKAN ROUTER ]
                    </button>
                  </div>
                )}

              {/* KONDISI 5: Form Autentikasi Router (Saat Pengguna Menekan [ HUBUNGKAN ROUTER ]) */}
              {showAuthForm && (
                <div className="mt-5">
                  <div className="mb-3 text-center">
                    <p className="text-xs font-extrabold text-blue-100">
                      "Digunakan untuk menghubungkan aplikasi ke router rumah."
                    </p>
                  </div>

                  {errorMessage && (
                    <div className="mb-4 p-3 rounded-xl bg-red-500 text-white flex items-center gap-2 text-xs font-bold shadow-md">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{errorMessage}</span>
                    </div>
                  )}

                  <form onSubmit={handleLoginSubmit} className="space-y-4">
                    <div>
                      <label
                        htmlFor="username"
                        className="block text-xs font-black uppercase tracking-wide text-white mb-1.5 pl-0.5"
                      >
                        Nama pengguna router
                      </label>
                      <input
                        id="username"
                        type="text"
                        value={username}
                        onChange={(e) => {
                          setUsername(e.target.value);
                          if (errorMessage) setErrorMessage('');
                        }}
                        placeholder="Masukkan nama pengguna router"
                        autoComplete="username"
                        className="w-full h-13 px-4 rounded-xl bg-white text-slate-900 font-bold text-sm placeholder-slate-400 border-2 border-white focus:outline-none focus:ring-4 focus:ring-white/30 transition-all shadow-sm"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="password"
                        className="block text-xs font-black uppercase tracking-wide text-white mb-1.5 pl-0.5"
                      >
                        Password router
                      </label>
                      <div className="relative">
                        <input
                          id="password"
                          type={showPassword ? 'text' : 'password'}
                          value={password}
                          onChange={(e) => {
                            setPassword(e.target.value);
                            if (errorMessage) setErrorMessage('');
                          }}
                          placeholder="Masukkan password router"
                          autoComplete="current-password"
                          className="w-full h-13 pl-4 pr-12 rounded-xl bg-white text-slate-900 font-bold text-sm placeholder-slate-400 border-2 border-white focus:outline-none focus:ring-4 focus:ring-white/30 transition-all shadow-sm"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          aria-label={showPassword ? 'Sembunyikan password' : 'Lihat password'}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 w-9 h-9 rounded-lg flex items-center justify-center text-slate-500 hover:text-[#0C44AC] transition-colors"
                        >
                          {showPassword ? (
                            <EyeOff className="w-5 h-5 stroke-[2]" />
                          ) : (
                            <Eye className="w-5 h-5 stroke-[2]" />
                          )}
                        </button>
                      </div>
                    </div>

                    <div className="pt-2 space-y-2">
                      <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full h-14 rounded-xl bg-white hover:bg-blue-50 active:bg-blue-100 text-[#08296B] font-black text-sm tracking-wider uppercase shadow-lg shadow-black/25 active:translate-y-0.5 transition-all flex items-center justify-center gap-2 border-2 border-white cursor-pointer"
                      >
                        {isLoading ? (
                          <div className="flex items-center gap-2">
                            <div className="w-4 h-4 border-2 border-[#0C44AC]/30 border-t-[#0C44AC] rounded-full animate-spin" />
                            <span>MENGHUBUNGKAN...</span>
                          </div>
                        ) : (
                          <span>[ HUBUNGKAN ROUTER ]</span>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setShowAuthForm(false);
                          setErrorMessage('');
                        }}
                        className="w-full h-10 rounded-xl bg-transparent hover:bg-white/10 text-blue-200 text-xs font-bold transition-colors cursor-pointer"
                      >
                        Batal
                      </button>
                    </div>
                  </form>
                </div>
              )}
            </div>

            <div className="px-7 py-3 bg-[#051C4D] text-center text-[11px] font-extrabold text-blue-200 flex items-center justify-center gap-1.5 border-t border-white/10">
              <Shield className="w-3.5 h-3.5 text-white" />
              <span>Koneksi Router Lokal Aman</span>
            </div>
          </div>
        )}

        {/* Navigasi Cepat Pengujian (Tab Bar di Bagian Bawah) */}
        <div className="mt-3 flex items-center justify-center gap-1 bg-white/10 backdrop-blur-md p-1.5 rounded-full border border-white/20 shadow-xs flex-wrap">
          <button
            type="button"
            onClick={() => setCurrentPage('login')}
            className={`px-2 py-0.5 rounded-full text-[10px] font-black tracking-wide uppercase transition-all ${
              currentPage === 'login'
                ? 'bg-white text-[#08296B] shadow-xs'
                : 'text-white/80 hover:text-white'
            }`}
          >
            Hubungkan
          </button>
          <button
            type="button"
            onClick={() => setCurrentPage('dashboard')}
            className={`px-2 py-0.5 rounded-full text-[10px] font-black tracking-wide uppercase transition-all ${
              currentPage === 'dashboard'
                ? 'bg-white text-[#08296B] shadow-xs'
                : 'text-white/80 hover:text-white'
            }`}
          >
            Dashboard
          </button>
          <button
            type="button"
            onClick={() => {
              loadDevices();
              setCurrentPage('devices');
            }}
            className={`px-2 py-0.5 rounded-full text-[10px] font-black tracking-wide uppercase transition-all ${
              currentPage === 'devices'
                ? 'bg-white text-[#08296B] shadow-xs'
                : 'text-white/80 hover:text-white'
            }`}
          >
            Perangkat
          </button>
          <button
            type="button"
            onClick={() => setCurrentPage('wifi_settings')}
            className={`px-2 py-0.5 rounded-full text-[10px] font-black tracking-wide uppercase transition-all ${
              currentPage === 'wifi_settings'
                ? 'bg-white text-[#08296B] shadow-xs'
                : 'text-white/80 hover:text-white'
            }`}
          >
            Wi-Fi
          </button>
          <button
            type="button"
            onClick={() => setCurrentPage('protection')}
            className={`px-2 py-0.5 rounded-full text-[10px] font-black tracking-wide uppercase transition-all ${
              currentPage === 'protection'
                ? 'bg-white text-[#08296B] shadow-xs'
                : 'text-white/80 hover:text-white'
            }`}
          >
            🛡️ Perlindungan
          </button>
          <button
            type="button"
            onClick={() => setCurrentPage('history')}
            className={`px-2 py-0.5 rounded-full text-[10px] font-black tracking-wide uppercase transition-all ${
              currentPage === 'history'
                ? 'bg-white text-[#08296B] shadow-xs'
                : 'text-white/80 hover:text-white'
            }`}
          >
            📋 Riwayat
          </button>
          <button
            type="button"
            onClick={() => setCurrentPage('settings')}
            className={`px-2 py-0.5 rounded-full text-[10px] font-black tracking-wide uppercase transition-all ${
              currentPage === 'settings'
                ? 'bg-white text-[#08296B] shadow-xs'
                : 'text-white/80 hover:text-white'
            }`}
          >
            ⚙️ Pengaturan
          </button>
          <button
            type="button"
            onClick={() => setShowLogoutModal(true)}
            className="px-2 py-0.5 rounded-full text-[10px] font-black tracking-wide uppercase bg-red-500/80 hover:bg-red-600 text-white shadow-xs"
          >
            Modal Keluar
          </button>
        </div>

      </div>

    </div>
  );
}
