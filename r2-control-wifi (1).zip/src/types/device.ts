export type DeviceType = 'phone' | 'tv' | 'laptop' | 'tablet' | 'iot' | 'other';

export type DeviceTrustStatus = 'Dipercaya' | 'Tidak dikenal';

export interface ConnectedDevice {
  id: string;
  name: string;
  type: DeviceType;
  emoji: string;
  status: 'Terhubung'; // Sesuai aturan: gunakan 'Terhubung', bukan 'Online'
  trustStatus: DeviceTrustStatus;
  isTrusted: boolean;
  // Field data teknis dari router (siap digunakan saat integrasi API router sesungguhnya)
  ipAddress?: string;
  macAddress?: string;
  signalStrength?: number; // dBm atau persentase
  connectedTime?: string;
}

export interface RouterInfo {
  gatewayIp: string;
  ssid: string;
  bssid?: string;
  channel?: number;
  totalDevicesConnected: number;
}
