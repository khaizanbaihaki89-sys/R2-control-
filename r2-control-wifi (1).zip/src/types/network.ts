/**
 * Tipe data untuk informasi jaringan Android, router capability, dan sesi autentikasi router.
 */

export interface LocalNetworkInfo {
  isConnectedToWifi: boolean;
  networkType: 'wifi' | 'cellular' | 'ethernet' | 'offline' | 'unknown';
  ssid: string;
  bssid: string;
  deviceIp: string;
  gatewayIp: string;
  subnet: string;
  dnsServers?: string[];
  linkSpeedMbps?: number | 'Tidak tersedia';
  frequencyMhz?: number | 'Tidak tersedia';
  signalStrengthDbm?: number | 'Tidak tersedia';
  permissionGranted: boolean;
  permissionNote?: string;
  lastUpdated: string;
}

export interface RouterDetectionResult {
  isDetected: boolean;
  gatewayAddress: string;
  identity: string;
  detectedBrand?: string;
  detectedModel?: string;
  serverHeader?: string;
  firmwareInfo?: string;
  authTypeDetected?: string;
  openPorts?: number[];
  probeSummary: string;
  probeDurationMs: number;
  timestamp: string;
}

export interface RouterCapability {
  gatewayReachable: boolean;
  httpAvailable: boolean;
  httpsAvailable: boolean;
  localAdminPageDetected: 'Tersedia' | 'Tidak diketahui' | 'Tidak tersedia';
  detectedVendor: string;
  detectedModel: string;
  supportedAccessMethods: string[];
  checkedAt: string;
  status: string;
  errorMessage?: string;
}

export type RouterSessionState =
  | 'DISCONNECTED'
  | 'DETECTED'
  | 'AUTHENTICATING'
  | 'AUTHENTICATED'
  | 'AUTH_FAILED'
  | 'SESSION_EXPIRED';

export interface RouterAuthCredentials {
  username: string;
  password: string;
}

export interface RouterAuthResult {
  success: boolean;
  state: RouterSessionState;
  statusMessage: string;
  gatewayIp: string;
  authenticatedAt?: string;
  sessionExpiresAt?: string;
  authMethodUsed?: string;
  errorMessage?: string;
}

/**
 * Metadata sesi router non-rahasia (tidak menyimpan password plaintext)
 */
export interface RouterSessionMetadata {
  gatewayIp: string;
  ssid: string;
  bssid: string;
  vendor: string;
  model: string;
  authMethod: string;
  authenticatedAt: string;
  lastActive: string;
  sessionExpiresAt?: string;
}

/**
 * Data router rumah yang telah berhasil dihubungkan & disimpan pada perangkat ini
 */
export interface PairedRouterRecord {
  gatewayIp: string;
  ssid: string;
  bssid: string;
  vendor: string;
  model: string;
  pairedAt: string;
  sessionExpiresAt?: string;
}

export type NetworkMatchStatus =
  | 'MATCH'           // Wi-Fi & Gateway cocok dengan router yang tersimpan
  | 'DIFFERENT_WIFI'  // Terhubung ke Wi-Fi lain
  | 'OFFLINE'         // Tidak terhubung ke Wi-Fi
  | 'UNPAIRED';       // Belum ada router yang terdaftar di perangkat ini

export interface RouterDiagnosticReport {
  network: LocalNetworkInfo;
  router: RouterDetectionResult;
  capability?: RouterCapability;
  authStatus: 'Belum dilakukan' | 'Berhasil' | 'Gagal' | 'Terhubung';
  sessionStatus: 'Aktif' | 'Tidak aktif';
  controlAvailable: boolean;
  statusMessage: string;
}
