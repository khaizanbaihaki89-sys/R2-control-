import {
  RouterDetectionResult,
  RouterCapability,
  RouterAuthCredentials,
  RouterAuthResult,
} from '../../types/network';

/**
 * Interface dasar untuk Router Adapter.
 * Siap diperluas untuk berbagai merek router lokal (TP-Link, ZTE, Huawei, Tenda, MikroTik, dll.)
 */
export interface RouterAdapter {
  brandName: string;
  supportedModels: string[];

  /**
   * Menentukan apakah router yang terdeteksi cocok dengan adapter ini
   */
  canHandle(detection: RouterDetectionResult, capability?: RouterCapability): boolean;

  /**
   * Mengirim request autentikasi khusus vendor (akan digunakan bila router memerlukan format/algoritma khusus)
   */
  authenticate?(
    gatewayIp: string,
    credentials: RouterAuthCredentials,
    capability?: RouterCapability
  ): Promise<RouterAuthResult>;

  /**
   * Mengambil informasi status router setelah teridentifikasi (akan diimplementasikan di tahap selanjutnya)
   */
  getRouterInfo?(gatewayIp: string): Promise<any>;
}

/**
 * Registry untuk mengelola modul-modul Router Adapter
 */
export class RouterAdapterRegistry {
  private static adapters: RouterAdapter[] = [];

  public static registerAdapter(adapter: RouterAdapter): void {
    this.adapters.push(adapter);
  }

  public static findAdapter(
    detection: RouterDetectionResult,
    capability?: RouterCapability
  ): RouterAdapter | null {
    for (const adapter of this.adapters) {
      if (adapter.canHandle(detection, capability)) {
        return adapter;
      }
    }
    return null;
  }

  public static getAllAdapters(): RouterAdapter[] {
    return [...this.adapters];
  }
}
