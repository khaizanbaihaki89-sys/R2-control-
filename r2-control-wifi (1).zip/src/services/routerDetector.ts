import { RouterDetectionResult } from '../types/network';

/**
 * Service untuk mendeteksi dan mengidentifikasi router lokal secara aman.
 * 
 * Aturan Penting:
 * 1. Hanya memeriksa alamat gateway lokal perangkat (misal 192.168.1.1).
 * 2. Tidak melakukan scanning internet atau host di luar jaringan lokal.
 * 3. Tidak menggunakan VPS, cloud server, atau layanan pihak ketiga.
 * 4. Tidak mencoba login ke router.
 * 5. Jika tidak dapat diidentifikasi, nyatakan "Belum berhasil diidentifikasi" (tanpa mock palsu).
 */
export async function detectLocalRouter(gatewayIp: string): Promise<RouterDetectionResult> {
  const startTime = Date.now();
  const timestamp = new Date().toLocaleTimeString('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  // Validasi format alamat IPv4 gateway
  if (!gatewayIp || gatewayIp === 'Tidak tersedia' || !/^(\d{1,3}\.){3}\d{1,3}$/.test(gatewayIp)) {
    return {
      isDetected: false,
      gatewayAddress: gatewayIp || 'Tidak tersedia',
      identity: 'Belum berhasil diidentifikasi',
      probeSummary: 'Alamat gateway lokal tidak valid atau tidak tersedia.',
      probeDurationMs: Date.now() - startTime,
      timestamp,
    };
  }

  const probeUrls = [
    `http://${gatewayIp}`,
    `http://${gatewayIp}:80`,
    `http://${gatewayIp}:8080`,
  ];

  let isHttpResponding = false;
  let serverHeaderFound = '';
  let identifiedBrand = '';
  let identifiedModel = '';

  for (const url of probeUrls) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 1800); // Timeout singkat & aman

      // Probe lokal menggunakan fetch standar
      // mode: 'no-cors' digunakan untuk memeriksa respon lokal tanpa melanggar CORS di browser/WebView
      const response = await fetch(url, {
        method: 'GET',
        mode: 'no-cors',
        signal: controller.signal,
        cache: 'no-cache',
      });

      clearTimeout(timeoutId);

      // Jika fetch berhasil mencapai socket gateway lokal (tipe 'opaque' atau 'basic')
      if (response) {
        isHttpResponding = true;

        // Jika response header dapat dibaca (mode cors jika didukung router)
        if (response.headers) {
          const serverHdr = response.headers.get('server');
          if (serverHdr) {
            serverHeaderFound = serverHdr;
            // Analisis signature server umum router
            if (/micro_httpd|rompager|miniupnpd|boa|goahead|lighttpd/i.test(serverHdr)) {
              if (/tplink|tp-link/i.test(serverHdr)) {
                identifiedBrand = 'TP-Link';
              } else if (/zte/i.test(serverHdr)) {
                identifiedBrand = 'ZTE';
              } else if (/huawei/i.test(serverHdr)) {
                identifiedBrand = 'Huawei';
              } else if (/mikrotik|routeros/i.test(serverHdr)) {
                identifiedBrand = 'MikroTik';
              }
            }
          }
        }
        break; // Berhenti setelah menemukan port gateway yang aktif
      }
    } catch (err: any) {
      // Jika terjadi abort (timeout) atau host unreachable, lanjut ke port berikutnya
      if (err.name !== 'AbortError') {
        // Pada WebView / browser, TypeError 'Failed to fetch' seringkali merupakan tanda bahwa host ada
        // tetapi memblokir CORS browser, atau port tertutup.
      }
    }
  }

  const duration = Date.now() - startTime;

  // Jika router berhasil merespon HTTP secara lokal
  if (isHttpResponding) {
    let identityName = 'Belum berhasil diidentifikasi';
    if (identifiedBrand) {
      identityName = identifiedModel ? `${identifiedBrand} ${identifiedModel}` : identifiedBrand;
    }

    return {
      isDetected: true,
      gatewayAddress: gatewayIp,
      identity: identityName,
      detectedBrand: identifiedBrand || undefined,
      detectedModel: identifiedModel || undefined,
      serverHeader: serverHeaderFound || undefined,
      probeSummary: `Gateway lokal ${gatewayIp} merespon di jaringan Wi-Fi lokal.`,
      probeDurationMs: duration,
      timestamp,
    };
  }

  // Jika tidak dapat diidentifikasi atau tidak merespon probe HTTP
  return {
    isDetected: false,
    gatewayAddress: gatewayIp,
    identity: 'Belum berhasil diidentifikasi',
    probeSummary: `Gateway lokal ${gatewayIp} belum merespon probe HTTP lokal.`,
    probeDurationMs: duration,
    timestamp,
  };
}
