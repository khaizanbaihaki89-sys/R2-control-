import { RouterCapability } from '../types/network';

/**
 * Service untuk memeriksa kemampuan komunikasi router lokal (Capability Check).
 * 
 * Aturan Ketat:
 * 1. Hanya memeriksa alamat gateway router yang sudah ditemukan (misal 192.168.1.1).
 * 2. 100% lokal di jaringan Wi-Fi perangkat: Tanpa internet, cloud, VPS, domain eksternal, atau layanan pihak ketiga.
 * 3. Tanpa login dan tanpa mengubah konfigurasi apa pun.
 * 4. Tanpa port scanning agresif.
 * 5. Tanpa menebak merek berdasarkan IP dan tanpa data mock/palsu.
 * 6. Jika terhalang batasan CORS/keamanan WebView browser, kembalikan status:
 *    "Pemeriksaan lokal membutuhkan Android native bridge".
 */
export async function checkRouterCapability(gatewayIp: string): Promise<RouterCapability> {
  const checkedAt = new Date().toLocaleTimeString('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  // Validasi dasar alamat IP gateway
  if (!gatewayIp || gatewayIp === 'Tidak tersedia' || !/^(\d{1,3}\.){3}\d{1,3}$/.test(gatewayIp)) {
    return {
      gatewayReachable: false,
      httpAvailable: false,
      httpsAvailable: false,
      localAdminPageDetected: 'Tidak tersedia',
      detectedVendor: 'Belum diketahui',
      detectedModel: 'Belum diketahui',
      supportedAccessMethods: ['Belum diketahui'],
      checkedAt,
      status: 'Gateway tidak valid atau tidak tersedia',
      errorMessage: 'Alamat gateway lokal tidak ditemukan pada konfigurasi jaringan.',
    };
  }

  // 1. Periksa apakah ada Android Native Bridge yang menyediakan kemampuan inspeksi soket lokal
  if (typeof window !== 'undefined') {
    const nativeBridge = (window as any).AndroidRouterBridge || (window as any).AndroidBridge;
    if (nativeBridge && typeof nativeBridge.checkGatewayCapability === 'function') {
      try {
        const nativeResult = await nativeBridge.checkGatewayCapability(gatewayIp);
        if (nativeResult) {
          return {
            gatewayReachable: Boolean(nativeResult.reachable),
            httpAvailable: Boolean(nativeResult.http),
            httpsAvailable: Boolean(nativeResult.https),
            localAdminPageDetected: nativeResult.adminPage ? 'Tersedia' : 'Tidak diketahui',
            detectedVendor: nativeResult.vendor || 'Belum diketahui',
            detectedModel: nativeResult.model || 'Belum diketahui',
            supportedAccessMethods: nativeResult.methods || ['HTTP Web UI'],
            checkedAt,
            status: nativeResult.status || 'Siap untuk autentikasi',
          };
        }
      } catch (err) {
        console.warn('Gagal membaca capability dari Android Native Bridge:', err);
      }
    }
  }

  // 2. Pemeriksaan lokal aman via HTTP/HTTPS menggunakan AbortController dengan timeout pendek (1.5 detik)
  let httpOk = false;
  let httpsOk = false;
  let isCorsRestricted = false;
  let detectedVendor = 'Belum diketahui';
  let detectedModel = 'Belum diketahui';

  // Periksa protokol HTTP lokal
  try {
    const httpController = new AbortController();
    const httpTimer = setTimeout(() => httpController.abort(), 1500);

    const httpResponse = await fetch(`http://${gatewayIp}`, {
      method: 'GET',
      mode: 'no-cors', // Menghindari browser langsung memblokir preflight ke LAN
      signal: httpController.signal,
      cache: 'no-cache',
    });

    clearTimeout(httpTimer);

    if (httpResponse) {
      httpOk = true;
      // Periksa apakah server header dapat dibaca (jika router merespons dengan header CORS terbuka)
      if (httpResponse.headers) {
        const srv = httpResponse.headers.get('server');
        if (srv) {
          if (/tplink|tp-link/i.test(srv)) detectedVendor = 'TP-Link';
          else if (/zte/i.test(srv)) detectedVendor = 'ZTE';
          else if (/huawei/i.test(srv)) detectedVendor = 'Huawei';
          else if (/mikrotik|routeros/i.test(srv)) detectedVendor = 'MikroTik';
        }
      }
    }
  } catch (err: any) {
    if (err.name === 'AbortError') {
      // Timeout: Gateway tidak merespon di port HTTP standar
      httpOk = false;
    } else if (err instanceof TypeError) {
      // Pada browser Web / WebView standar, kebijakan Private Network Access (PNA)
      // membatasi inspeksi silang ke IP lokal (CORS/Security restriction)
      isCorsRestricted = true;
    }
  }

  // Periksa protokol HTTPS lokal secara aman
  try {
    const httpsController = new AbortController();
    const httpsTimer = setTimeout(() => httpsController.abort(), 1200);

    const httpsResponse = await fetch(`https://${gatewayIp}`, {
      method: 'GET',
      mode: 'no-cors',
      signal: httpsController.signal,
      cache: 'no-cache',
    });

    clearTimeout(httpsTimer);

    if (httpsResponse) {
      httpsOk = true;
    }
  } catch (_) {
    // Port HTTPS tidak aktif atau sertifikat TLS lokal ditolak browser
    httpsOk = false;
  }

  // Tentukan metode akses yang terdeteksi
  const accessMethods: string[] = [];
  if (httpOk) accessMethods.push('HTTP Web UI');
  if (httpsOk) accessMethods.push('HTTPS Web UI');

  // Penentuan status terstruktur berdasarkan hasil pemeriksaan lokal
  if (httpOk || httpsOk) {
    return {
      gatewayReachable: true,
      httpAvailable: httpOk,
      httpsAvailable: httpsOk,
      localAdminPageDetected: 'Tersedia',
      detectedVendor,
      detectedModel,
      supportedAccessMethods: accessMethods.length > 0 ? accessMethods : ['HTTP Web UI'],
      checkedAt,
      status: 'Siap untuk autentikasi',
    };
  }

  // Jika terkena pembatasan keamanan browser/WebView (PNA / CORS lokal)
  if (isCorsRestricted) {
    return {
      gatewayReachable: true, // Gateway lokal terdeteksi ada di jaringan
      httpAvailable: false,
      httpsAvailable: false,
      localAdminPageDetected: 'Tidak diketahui',
      detectedVendor: 'Belum diketahui',
      detectedModel: 'Belum diketahui',
      supportedAccessMethods: ['Belum diketahui'],
      checkedAt,
      status: 'Pemeriksaan lokal membutuhkan Android native bridge',
      errorMessage: 'Kebijakan Private Network Access (CORS) membatasi inspeksi HTTP langsung di WebView browser.',
    };
  }

  // Jika gateway sama sekali tidak merespon probe lokal
  return {
    gatewayReachable: false,
    httpAvailable: false,
    httpsAvailable: false,
    localAdminPageDetected: 'Tidak diketahui',
    detectedVendor: 'Belum diketahui',
    detectedModel: 'Belum diketahui',
    supportedAccessMethods: ['Belum diketahui'],
    checkedAt,
    status: 'Gateway tidak merespons',
    errorMessage: `Gateway ${gatewayIp} tidak merespons probe antarmuka lokal dalam batas waktu.`,
  };
}
