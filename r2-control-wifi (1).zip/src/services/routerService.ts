import { ConnectedDevice, RouterInfo } from '../types/device';

/**
 * Data preview tampilan (sesuai spesifikasi UI Tahap 3).
 * Catatan penting: Data ini hanya untuk preview tampilan desain awal.
 * Nantinya daftar perangkat akan diambil secara dinamis dari API/DHCP table router pengguna.
 */
export const PREVIEW_CONNECTED_DEVICES: ConnectedDevice[] = [
  {
    id: 'dev-001',
    name: 'HP Saya',
    type: 'phone',
    emoji: '📱',
    status: 'Terhubung',
    trustStatus: 'Dipercaya',
    isTrusted: true,
    ipAddress: '192.168.1.101',
    macAddress: '8C:85:90:3A:42:11',
    signalStrength: 95,
  },
  {
    id: 'dev-002',
    name: 'Smart TV',
    type: 'tv',
    emoji: '📺',
    status: 'Terhubung',
    trustStatus: 'Dipercaya',
    isTrusted: true,
    ipAddress: '192.168.1.102',
    macAddress: '3C:2E:F9:6B:18:22',
    signalStrength: 88,
  },
  {
    id: 'dev-003',
    name: 'Laptop',
    type: 'laptop',
    emoji: '💻',
    status: 'Terhubung',
    trustStatus: 'Dipercaya',
    isTrusted: true,
    ipAddress: '192.168.1.103',
    macAddress: 'F0:18:98:8C:55:33',
    signalStrength: 92,
  },
  {
    id: 'dev-004',
    name: 'Redmi',
    type: 'phone',
    emoji: '📱',
    status: 'Terhubung',
    trustStatus: 'Tidak dikenal',
    isTrusted: false,
    ipAddress: '192.168.1.104',
    macAddress: '64:A2:F9:11:44:88',
    signalStrength: 76,
  },
  {
    id: 'dev-005',
    name: 'iPhone',
    type: 'phone',
    emoji: '📱',
    status: 'Terhubung',
    trustStatus: 'Tidak dikenal',
    isTrusted: false,
    ipAddress: '192.168.1.105',
    macAddress: 'F8:E0:79:22:99:AA',
    signalStrength: 70,
  },
];

export const DEFAULT_ROUTER_INFO: RouterInfo = {
  gatewayIp: '192.168.1.1',
  ssid: 'Wi-Fi Rumah',
  totalDevicesConnected: 5,
};

/**
 * Service untuk mengambil daftar perangkat terhubung dari router.
 * Struktur ini sudah siap dihubungkan ke endpoint backend proxy / router API sesungguhnya.
 */
export async function getConnectedDevicesFromRouter(): Promise<ConnectedDevice[]> {
  try {
    // Apabila sudah ada backend endpoint router aktif (misal /api/router/devices),
    // sistem akan otomatis mengambil data riil dari router:
    if (typeof window !== 'undefined' && (window as any).__ROUTER_API_ENDPOINT__) {
      const response = await fetch((window as any).__ROUTER_API_ENDPOINT__);
      if (response.ok) {
        const liveDevices: ConnectedDevice[] = await response.json();
        return liveDevices;
      }
    }

    // Default saat ini: gunakan data contoh sebagai preview UI
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve([...PREVIEW_CONNECTED_DEVICES]);
      }, 350);
    });
  } catch (error) {
    console.error('Gagal mengambil data perangkat dari router, menggunakan fallback preview UI:', error);
    return PREVIEW_CONNECTED_DEVICES;
  }
}
