import {
  RouterSessionState,
  RouterAuthCredentials,
  RouterAuthResult,
  RouterSessionMetadata,
  RouterCapability,
  LocalNetworkInfo,
  PairedRouterRecord,
  NetworkMatchStatus,
} from '../types/network';
import {
  isAndroidNativeBridgeAvailable,
  nativeAuthenticateRouter,
  nativeEndRouterSession,
} from './androidNetworkBridge';

type SessionChangeListener = (
  state: RouterSessionState,
  metadata: RouterSessionMetadata | null,
  matchStatus: NetworkMatchStatus
) => void;

const STORAGE_KEY = 'r2_paired_router_session';

/**
 * RouterSessionManager
 * 
 * Pengelola sesi & pairing router lokal secara aman.
 * - Mengelola status siklus hidup sesi:
 *   DISCONNECTED -> DETECTED -> AUTHENTICATING -> AUTHENTICATED -> AUTH_FAILED -> SESSION_EXPIRED
 * - Mengingat router yang telah berhasil dihubungkan pada perangkat ini.
 * - Saat aplikasi dibuka kembali di Wi-Fi yang sama: langsung masuk Dashboard dengan status "🟢 ROUTER TERHUBUNG" tanpa meminta password ulang!
 * - Menangani kondisi:
 *   1. Router ditemukan pertama kali -> "📡 ROUTER DITEMUKAN"
 *   2. Sesi kedaluwarsa -> "Sesi router telah berakhir." -> [ HUBUNGKAN KEMBALI ]
 *   3. HP terhubung ke Wi-Fi lain -> "🔴 Router rumah tidak tersedia"
 * - Tidak menyimpan password sebagai plaintext.
 */
export class RouterSessionManager {
  private static instance: RouterSessionManager;

  private state: RouterSessionState = 'DISCONNECTED';
  private sessionMetadata: RouterSessionMetadata | null = null;
  private pairedRouter: PairedRouterRecord | null = null;
  private matchStatus: NetworkMatchStatus = 'UNPAIRED';
  private listeners: Set<SessionChangeListener> = new Set();
  private verifiedGatewayIp: string = '';

  private constructor() {
    this.loadStoredPairedSession();
  }

  public static getInstance(): RouterSessionManager {
    if (!RouterSessionManager.instance) {
      RouterSessionManager.instance = new RouterSessionManager();
    }
    return RouterSessionManager.instance;
  }

  /**
   * Membaca data router terdaftar dari secure storage / browser persistence
   */
  private loadStoredPairedSession(): void {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        const raw = window.localStorage.getItem(STORAGE_KEY);
        if (raw) {
          const parsed: PairedRouterRecord = JSON.parse(raw);
          if (parsed && parsed.gatewayIp) {
            this.pairedRouter = parsed;
            this.sessionMetadata = {
              gatewayIp: parsed.gatewayIp,
              ssid: parsed.ssid || 'Wi-Fi Rumah',
              bssid: parsed.bssid || 'Tidak tersedia',
              vendor: parsed.vendor || 'Belum diketahui',
              model: parsed.model || 'Belum diketahui',
              authMethod: 'Tersimpan',
              authenticatedAt: parsed.pairedAt,
              lastActive: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
              sessionExpiresAt: parsed.sessionExpiresAt,
            };
            const isExpired = parsed.sessionExpiresAt
              ? new Date(parsed.sessionExpiresAt).getTime() < Date.now()
              : false;
            this.state = isExpired ? 'SESSION_EXPIRED' : 'AUTHENTICATED';
          }
        }
      }
    } catch (_) {
      this.pairedRouter = null;
    }
  }

  /**
   * Menyimpan router yang berhasil dihubungkan ke penyimpanan perangkat
   */
  public savePairedSession(metadata: RouterSessionMetadata, expiresAt?: string): void {
    this.pairedRouter = {
      gatewayIp: metadata.gatewayIp,
      ssid: metadata.ssid,
      bssid: metadata.bssid,
      vendor: metadata.vendor,
      model: metadata.model,
      pairedAt: metadata.authenticatedAt,
      sessionExpiresAt: expiresAt || metadata.sessionExpiresAt,
    };

    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(this.pairedRouter));
      }
    } catch (e) {
      console.warn('Gagal menyimpan sesi router ke penyimpanan perangkat:', e);
    }
  }

  /**
   * Menghapus sesi router tersimpan (misal saat logout permanen)
   */
  public clearPairedSession(): void {
    this.pairedRouter = null;
    this.sessionMetadata = null;
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.removeItem(STORAGE_KEY);
      }
    } catch (_) {}
  }

  public getState(): RouterSessionState {
    return this.state;
  }

  public getSessionMetadata(): RouterSessionMetadata | null {
    return this.sessionMetadata;
  }

  public getPairedRouter(): PairedRouterRecord | null {
    return this.pairedRouter;
  }

  public getMatchStatus(): NetworkMatchStatus {
    return this.matchStatus;
  }

  public isRouterPaired(): boolean {
    return this.pairedRouter !== null;
  }

  public isSessionActive(): boolean {
    return this.state === 'AUTHENTICATED';
  }

  public isSessionExpired(): boolean {
    if (!this.pairedRouter?.sessionExpiresAt) {
      return false;
    }
    const expiryTime = new Date(this.pairedRouter.sessionExpiresAt).getTime();
    return !isNaN(expiryTime) && Date.now() > expiryTime;
  }

  public subscribe(listener: SessionChangeListener): () => void {
    this.listeners.add(listener);
    listener(this.state, this.sessionMetadata, this.matchStatus);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notifyListeners(): void {
    for (const listener of this.listeners) {
      try {
        listener(this.state, this.sessionMetadata, this.matchStatus);
      } catch (err) {
        console.error('Error notifying session listener:', err);
      }
    }
  }

  public setVerifiedGateway(gatewayIp: string): void {
    if (gatewayIp && gatewayIp !== 'Tidak tersedia') {
      this.verifiedGatewayIp = gatewayIp;
    }
  }

  /**
   * Memvalidasi jaringan Wi-Fi terkini dengan router yang sudah terdaftar
   */
  public evaluateNetwork(networkInfo: LocalNetworkInfo): NetworkMatchStatus {
    if (!networkInfo.isConnectedToWifi) {
      this.matchStatus = 'OFFLINE';
      this.state = 'DISCONNECTED';
      this.notifyListeners();
      return 'OFFLINE';
    }

    if (!this.pairedRouter) {
      this.matchStatus = 'UNPAIRED';
      this.state = 'DETECTED';
      this.notifyListeners();
      return 'UNPAIRED';
    }

    // Periksa apakah gateway atau SSID cocok dengan router rumah terdaftar
    const currentGateway = networkInfo.gatewayIp;
    const isGatewayMatch = currentGateway && currentGateway === this.pairedRouter.gatewayIp;
    const isSsidMatch =
      networkInfo.ssid &&
      networkInfo.ssid !== 'Tidak tersedia' &&
      this.pairedRouter.ssid &&
      this.pairedRouter.ssid !== 'Tidak tersedia' &&
      networkInfo.ssid === this.pairedRouter.ssid;

    // Jika berada di jaringan yang sama
    if (isGatewayMatch || isSsidMatch) {
      if (this.isSessionExpired()) {
        this.matchStatus = 'MATCH';
        this.state = 'SESSION_EXPIRED';
        this.notifyListeners();
        return 'MATCH';
      }

      // Router sama dan sesi valid: Otomatis TERHUBUNG!
      this.matchStatus = 'MATCH';
      this.state = 'AUTHENTICATED';
      if (!this.sessionMetadata) {
        this.sessionMetadata = {
          gatewayIp: this.pairedRouter.gatewayIp,
          ssid: networkInfo.ssid !== 'Tidak tersedia' ? networkInfo.ssid : this.pairedRouter.ssid,
          bssid: networkInfo.bssid !== 'Tidak tersedia' ? networkInfo.bssid : this.pairedRouter.bssid,
          vendor: this.pairedRouter.vendor,
          model: this.pairedRouter.model,
          authMethod: 'Tersimpan',
          authenticatedAt: this.pairedRouter.pairedAt,
          lastActive: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
        };
      }
      this.notifyListeners();
      return 'MATCH';
    }

    // Jika terhubung ke Wi-Fi lain
    this.matchStatus = 'DIFFERENT_WIFI';
    this.state = 'DISCONNECTED';
    this.notifyListeners();
    return 'DIFFERENT_WIFI';
  }

  /**
   * Mengirim request autentikasi ke router lokal
   */
  public async authenticate(
    credentials: RouterAuthCredentials,
    capability: RouterCapability,
    networkInfo: LocalNetworkInfo
  ): Promise<RouterAuthResult> {
    const timestamp = new Date().toLocaleTimeString('id-ID', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });

    if (!networkInfo.isConnectedToWifi) {
      this.state = 'DISCONNECTED';
      this.matchStatus = 'OFFLINE';
      this.notifyListeners();
      return {
        success: false,
        state: 'DISCONNECTED',
        gatewayIp: networkInfo.gatewayIp,
        statusMessage: 'Router tidak dapat dijangkau melalui jaringan lokal.',
        errorMessage: 'Perangkat tidak terhubung ke jaringan Wi-Fi lokal.',
      };
    }

    const targetGateway = this.verifiedGatewayIp || networkInfo.gatewayIp;
    if (!targetGateway || targetGateway === 'Tidak tersedia') {
      this.state = 'AUTH_FAILED';
      this.notifyListeners();
      return {
        success: false,
        state: 'AUTH_FAILED',
        gatewayIp: 'Tidak tersedia',
        statusMessage: 'Gateway belum diverifikasi.',
        errorMessage: 'Alamat gateway router lokal belum ditemukan atau belum diverifikasi.',
      };
    }

    const supportedMethods = capability.supportedAccessMethods || [];
    const isMethodKnown =
      supportedMethods.length > 0 &&
      supportedMethods[0] !== 'Belum diketahui' &&
      supportedMethods[0] !== 'Tidak tersedia';

    const accessMethod = isMethodKnown ? supportedMethods[0] : 'HTTP Web UI';

    this.state = 'AUTHENTICATING';
    this.notifyListeners();

    if (!isAndroidNativeBridgeAvailable()) {
      this.state = 'AUTH_FAILED';
      this.notifyListeners();
      return {
        success: false,
        state: 'AUTH_FAILED',
        gatewayIp: targetGateway,
        statusMessage: 'Koneksi router membutuhkan aplikasi Android.',
        errorMessage: 'Koneksi router membutuhkan aplikasi Android (Native Bridge belum terpasang).',
      };
    }

    try {
      const authResult = await nativeAuthenticateRouter(targetGateway, credentials, accessMethod);

      if (authResult.success) {
        this.state = 'AUTHENTICATED';
        this.matchStatus = 'MATCH';
        
        const metadata: RouterSessionMetadata = {
          gatewayIp: targetGateway,
          ssid: networkInfo.ssid !== 'Tidak tersedia' ? networkInfo.ssid : 'Wi-Fi Rumah',
          bssid: networkInfo.bssid !== 'Tidak tersedia' ? networkInfo.bssid : 'Tidak tersedia',
          vendor: capability.detectedVendor || 'Belum diketahui',
          model: capability.detectedModel || 'Belum diketahui',
          authMethod: accessMethod,
          authenticatedAt: timestamp,
          lastActive: timestamp,
          sessionExpiresAt: authResult.sessionExpiresAt,
        };

        this.sessionMetadata = metadata;
        // Simpan sesi terhubung pada perangkat ini
        this.savePairedSession(metadata, authResult.sessionExpiresAt);

        this.notifyListeners();
        return authResult;
      } else {
        this.state = 'AUTH_FAILED';
        this.notifyListeners();
        return authResult;
      }
    } catch (err: any) {
      this.state = 'AUTH_FAILED';
      this.notifyListeners();
      return {
        success: false,
        state: 'AUTH_FAILED',
        gatewayIp: targetGateway,
        statusMessage: 'Autentikasi gagal',
        errorMessage: err?.message || 'Terjadi kesalahan saat memproses autentikasi router.',
      };
    }
  }

  /**
   * Mengakhiri sesi aktif router (Logout dari router)
   */
  public async logoutRouter(): Promise<void> {
    if (this.sessionMetadata?.gatewayIp) {
      await nativeEndRouterSession(this.sessionMetadata.gatewayIp);
    }
    this.clearPairedSession();
    this.state = this.verifiedGatewayIp ? 'DETECTED' : 'DISCONNECTED';
    this.matchStatus = 'UNPAIRED';
    this.notifyListeners();
  }

  public resetSession(): void {
    this.clearPairedSession();
    this.state = 'DISCONNECTED';
    this.matchStatus = 'UNPAIRED';
    this.notifyListeners();
  }
}
