import { LocalNetworkInfo, RouterAuthCredentials, RouterAuthResult } from '../types/network';

// Deklarasi global bridge Android untuk WebView / Android wrapper
declare global {
  interface Window {
    AndroidRouterBridge?: {
      isConnectedToWifi?: () => boolean;
      getSsid?: () => string;
      getBssid?: () => string;
      getDeviceIp?: () => string;
      getGatewayIp?: () => string;
      getSubnetMask?: () => string;
      getLinkSpeed?: () => number;
      getFrequency?: () => number;
      hasLocationPermission?: () => boolean;
      // Fungsi autentikasi router via Android Native Bridge
      checkGatewayReachability?: (gatewayIp: string) => boolean | Promise<boolean>;
      authenticateRouter?: (gatewayIp: string, credentialsJson: string, method: string) => string | Promise<string>;
      endRouterSession?: (gatewayIp: string) => boolean | Promise<boolean>;
      getStoredSessionStatus?: (gatewayIp: string) => string | Promise<string>;
    };
    AndroidNetworkBridge?: any;
    AndroidBridge?: any;
  }
}

/**
 * Memeriksa apakah Android Native Bridge terpasang dan siap digunakan
 */
export function isAndroidNativeBridgeAvailable(): boolean {
  if (typeof window === 'undefined') return false;
  return Boolean(
    window.AndroidRouterBridge ||
    window.AndroidNetworkBridge ||
    window.AndroidBridge
  );
}

/**
 * Memeriksa koneksi lokal ke gateway melalui Android Native Bridge
 */
export async function nativeCheckGatewayConnection(gatewayIp: string): Promise<boolean> {
  if (!isAndroidNativeBridgeAvailable()) {
    return false;
  }

  const bridge = window.AndroidRouterBridge || window.AndroidBridge;
  if (bridge && typeof bridge.checkGatewayReachability === 'function') {
    try {
      const res = await bridge.checkGatewayReachability(gatewayIp);
      return Boolean(res);
    } catch (_) {
      return false;
    }
  }

  return false;
}

/**
 * Mengirim request autentikasi ke gateway router lokal melalui Android Native Bridge.
 * Password tidak ditulis ke URL, tidak dicatat ke log, dan hanya dikirim via bridge lokal.
 */
export async function nativeAuthenticateRouter(
  gatewayIp: string,
  credentials: RouterAuthCredentials,
  method: string
): Promise<RouterAuthResult> {
  const timestamp = new Date().toLocaleTimeString('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  const bridge = window.AndroidRouterBridge || window.AndroidBridge;

  // Jika Android Native Bridge tidak tersedia
  if (!bridge || typeof bridge.authenticateRouter !== 'function') {
    return {
      success: false,
      state: 'AUTH_FAILED',
      gatewayIp,
      statusMessage: 'Pemeriksaan router membutuhkan Android native bridge.',
      errorMessage: 'Android Native Bridge belum terpasang pada runtime WebView saat ini.',
    };
  }

  try {
    // Serialisasi kredensial dalam memori lokal untuk bridge
    const payload = JSON.stringify({
      username: credentials.username,
      password: credentials.password,
    });

    const rawResponse = await bridge.authenticateRouter(gatewayIp, payload, method);
    
    // Parsing response terstruktur dari Android Kotlin/Java Native Bridge
    let parsed: any = null;
    if (typeof rawResponse === 'string') {
      try {
        parsed = JSON.parse(rawResponse);
      } catch (_) {
        parsed = { success: rawResponse === 'true' || rawResponse === 'SUCCESS' };
      }
    } else {
      parsed = rawResponse;
    }

    if (parsed && parsed.success) {
      return {
        success: true,
        state: 'AUTHENTICATED',
        gatewayIp,
        statusMessage: 'Router berhasil terhubung',
        authenticatedAt: timestamp,
        sessionExpiresAt: parsed.expiresAt || undefined,
        authMethodUsed: method,
      };
    }

    return {
      success: false,
      state: 'AUTH_FAILED',
      gatewayIp,
      statusMessage: 'Autentikasi gagal',
      errorMessage: parsed?.message || 'Kredensial akun router tidak diterima oleh gateway.',
    };
  } catch (error: any) {
    return {
      success: false,
      state: 'AUTH_FAILED',
      gatewayIp,
      statusMessage: 'Autentikasi gagal',
      errorMessage: error?.message || 'Terjadi kesalahan saat berkomunikasi dengan Android Native Bridge.',
    };
  }
}

/**
 * Mengakhiri sesi aktif router melalui Android Native Bridge
 */
export async function nativeEndRouterSession(gatewayIp: string): Promise<boolean> {
  const bridge = window.AndroidRouterBridge || window.AndroidBridge;
  if (bridge && typeof bridge.endRouterSession === 'function') {
    try {
      const res = await bridge.endRouterSession(gatewayIp);
      return Boolean(res);
    } catch (_) {
      return false;
    }
  }
  return true;
}

/**
 * Mencoba mendeteksi alamat IP lokal perangkat di jaringan LAN menggunakan WebRTC ICE candidates.
 * Metode ini sepenuhnya lokal dan tidak mengakses server eksternal.
 */
async function discoverLocalDeviceIp(): Promise<string | null> {
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      resolve(null);
    }, 1200);

    try {
      const RTCPeerConnectionClass =
        window.RTCPeerConnection ||
        (window as any).webkitRTCPeerConnection ||
        (window as any).mozRTCPeerConnection;

      if (!RTCPeerConnectionClass) {
        clearTimeout(timer);
        resolve(null);
        return;
      }

      const pc = new RTCPeerConnectionClass({ iceServers: [] });
      pc.createDataChannel('local-probe');

      pc.onicecandidate = (event: RTCPeerConnectionIceEvent) => {
        if (!event || !event.candidate || !event.candidate.candidate) {
          return;
        }

        const candidateStr = event.candidate.candidate;
        const ipRegex = /\b(192\.168\.\d{1,3}\.\d{1,3}|10\.\d{1,3}\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3})\b/;
        const match = candidateStr.match(ipRegex);

        if (match && match[1]) {
          clearTimeout(timer);
          try {
            pc.close();
          } catch (_) {}
          resolve(match[1]);
        }
      };

      pc.createOffer()
        .then((offer: RTCSessionDescriptionInit) => pc.setLocalDescription(offer))
        .catch(() => {
          clearTimeout(timer);
          resolve(null);
        });
    } catch (_) {
      clearTimeout(timer);
      resolve(null);
    }
  });
}

function deriveGatewayFromDeviceIp(deviceIp: string): string {
  if (!deviceIp || deviceIp === 'Tidak tersedia') {
    return '192.168.1.1';
  }

  const parts = deviceIp.split('.');
  if (parts.length === 4) {
    return `${parts[0]}.${parts[1]}.${parts[2]}.1`;
  }
  return '192.168.1.1';
}

/**
 * Mengambil informasi jaringan lokal dari Android (Native Bridge atau Browser Network APIs).
 */
export async function getLocalNetworkInfo(): Promise<LocalNetworkInfo> {
  const now = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    return {
      isConnectedToWifi: false,
      networkType: 'offline',
      ssid: 'Tidak tersedia',
      bssid: 'Tidak tersedia',
      deviceIp: 'Tidak tersedia',
      gatewayIp: 'Tidak tersedia',
      subnet: 'Tidak tersedia',
      permissionGranted: false,
      permissionNote: 'Perangkat tidak terhubung ke jaringan',
      lastUpdated: now,
    };
  }

  const nativeBridge =
    window.AndroidRouterBridge ||
    window.AndroidNetworkBridge ||
    window.AndroidBridge;

  if (nativeBridge) {
    try {
      const isWifi =
        typeof nativeBridge.isConnectedToWifi === 'function'
          ? nativeBridge.isConnectedToWifi()
          : true;

      const ssidRaw =
        typeof nativeBridge.getSsid === 'function' ? nativeBridge.getSsid() : '';
      const bssidRaw =
        typeof nativeBridge.getBssid === 'function' ? nativeBridge.getBssid() : '';
      const deviceIpRaw =
        typeof nativeBridge.getDeviceIp === 'function' ? nativeBridge.getDeviceIp() : '';
      const gatewayIpRaw =
        typeof nativeBridge.getGatewayIp === 'function' ? nativeBridge.getGatewayIp() : '';
      const subnetRaw =
        typeof nativeBridge.getSubnetMask === 'function' ? nativeBridge.getSubnetMask() : '';
      const linkSpeed =
        typeof nativeBridge.getLinkSpeed === 'function' ? nativeBridge.getLinkSpeed() : undefined;
      const frequency =
        typeof nativeBridge.getFrequency === 'function' ? nativeBridge.getFrequency() : undefined;
      const hasPermission =
        typeof nativeBridge.hasLocationPermission === 'function'
          ? nativeBridge.hasLocationPermission()
          : true;

      const isSsidRestricted =
        !ssidRaw ||
        ssidRaw === '<unknown ssid>' ||
        ssidRaw === '"<unknown ssid>"' ||
        ssidRaw.trim() === '';

      const ssid = isSsidRestricted ? 'Tidak tersedia' : ssidRaw.replace(/^"|"$/g, '');
      const bssid = !bssidRaw || bssidRaw === '02:00:00:00:00:00' ? 'Tidak tersedia' : bssidRaw;
      const deviceIp = deviceIpRaw || 'Tidak tersedia';
      const gatewayIp = gatewayIpRaw || deriveGatewayFromDeviceIp(deviceIp);
      const subnet = subnetRaw || '255.255.255.0';

      return {
        isConnectedToWifi: isWifi,
        networkType: isWifi ? 'wifi' : 'unknown',
        ssid,
        bssid,
        deviceIp,
        gatewayIp,
        subnet,
        linkSpeedMbps: linkSpeed && linkSpeed > 0 ? linkSpeed : 'Tidak tersedia',
        frequencyMhz: frequency && frequency > 0 ? frequency : 'Tidak tersedia',
        permissionGranted: hasPermission,
        permissionNote: isSsidRestricted
          ? 'SSID/BSSID dibatasi oleh Android (membutuhkan izin lokasi)'
          : undefined,
        lastUpdated: now,
      };
    } catch (e) {
      console.warn('Gagal membaca dari Android Native Bridge, beralih ke deteksi web lokal:', e);
    }
  }

  const navConnection = (navigator as any).connection || (navigator as any).mozConnection || (navigator as any).webkitConnection;
  const isWifiApi = navConnection ? navConnection.type === 'wifi' || navConnection.type === undefined : true;

  const discoveredIp = await discoverLocalDeviceIp();
  const deviceIp = discoveredIp || '192.168.1.105';
  const gatewayIp = deriveGatewayFromDeviceIp(deviceIp);

  return {
    isConnectedToWifi: isWifiApi && navigator.onLine,
    networkType: isWifiApi ? 'wifi' : 'unknown',
    ssid: 'Tidak tersedia',
    bssid: 'Tidak tersedia',
    deviceIp: deviceIp,
    gatewayIp: gatewayIp,
    subnet: '255.255.255.0',
    linkSpeedMbps: navConnection?.downlink ? Math.round(navConnection.downlink * 8) : 'Tidak tersedia',
    permissionGranted: false,
    permissionNote: 'Akses SSID/BSSID membutuhkan Android Native Bridge / Izin Lokasi',
    lastUpdated: now,
  };
}
