# R2 CONTROL WIFI - Android Native Wrapper & Native Bridge

Proyek ini menyediakan Android Native Wrapper lengkap untuk aplikasi **R2 CONTROL WIFI** (React/Vite).

## 📁 Struktur Direktori Android

```
android/
├── build.gradle                               # Root build script
├── settings.gradle                            # Inklusi modul :app
├── gradle.properties                          # Konfigurasi JVM & AndroidX
├── README.md
└── app/
    ├── build.gradle                           # App build config (compileSdk 34, minSdk 24)
    └── src/
        └── main/
            ├── AndroidManifest.xml            # Izin jaringan Wi-Fi, lokasi, & launcher
            ├── assets/
            │   └── public/                    # Build lokal React/Vite (index.html, js, css)
            ├── res/
            │   ├── values/
            │   │   ├── strings.xml            # App name: R2 CONTROL WIFI
            │   │   ├── colors.xml             # Warna dominan Persib blue (#0C44AC)
            │   │   └── styles.xml             # NoActionBar theme
            │   └── xml/
            │       └── network_security_config.xml # Keamanan koneksi HTTP LAN lokal
            └── java/com/r2/controlwifi/
                ├── MainActivity.java          # Inisialisasi WebView & injeksi bridge
                ├── bridge/
                │   └── AndroidRouterBridge.java # JavascriptInterface untuk WebView
                ├── network/
                │   └── WifiNetworkHelper.java   # Helper API Wi-Fi (SSID, IP, Gateway)
                ├── security/
                │   └── SecureStorageManager.java# Android Keystore / EncryptedSharedPreferences
                └── router/
                    └── LocalRouterAuthenticator.java # Otentikasi HTTP/HTTPS ke gateway lokal
```

## 🔌 API Native Bridge (`window.AndroidRouterBridge` & `window.AndroidBridge`)

Diinjeksikan langsung ke runtime WebView JavaScript:

| Metode Java (@JavascriptInterface) | Keterangan |
|---|---|
| `isConnectedToWifi(): boolean` | Memeriksa apakah terhubung ke Wi-Fi (bukan mobile data) |
| `getSsid(): String` | Membaca SSID Wi-Fi aktif (atau "Tidak tersedia") |
| `getBssid(): String` | Membaca MAC BSSID router (atau "Tidak tersedia") |
| `getDeviceIp(): String` | Alamat IPv4 lokal perangkat |
| `getGatewayIp(): String` | Alamat default gateway router LAN |
| `getSubnetMask(): String` | Subnet mask (misal `255.255.255.0`) |
| `getLinkSpeed(): int` | Kecepatan link Wi-Fi dalam Mbps |
| `getFrequency(): int` | Frekuensi Wi-Fi dalam MHz |
| `hasLocationPermission(): boolean` | Status izin lokasi untuk akses SSID/BSSID |
| `checkGatewayReachability(gatewayIp): boolean` | Ping / cek socket port 80/443/8080 gateway |
| `authenticateRouter(gatewayIp, credsJson, method): String` | Otentikasi kredensial lokal ke gateway |
| `endRouterSession(gatewayIp): boolean` | Menghapus sesi pairing aktif (Logout) |
| `getStoredSessionStatus(gatewayIp): String` | Memeriksa kecocokan router rumah & masa berlaku sesi |

## 🛠️ Cara Membangun APK

1. **Sinkronisasi Build Web**:
   ```bash
   npm run build:android
   ```
2. **Buka di Android Studio**:
   - Buka folder `android/` di Android Studio.
   - Sinkronkan Gradle (`Sync Project with Gradle Files`).
   - Jalankan di emulator atau perangkat fisik Android, atau build APK via `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
3. **Build via CLI (Gradle)**:
   ```bash
   cd android
   ./gradlew assembleDebug
   ```
   APK akan tersedia di: `android/app/build/outputs/apk/debug/app-debug.apk`.
