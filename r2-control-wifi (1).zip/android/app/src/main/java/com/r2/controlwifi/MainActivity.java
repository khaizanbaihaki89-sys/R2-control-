package com.r2.controlwifi;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.r2.controlwifi.bridge.AndroidRouterBridge;

import java.util.ArrayList;
import java.util.List;

/**
 * MainActivity
 * 
 * Launcher Activity Android untuk aplikasi R2 CONTROL WIFI.
 * - Menginisialisasi WebView dan memuat build web React/Vite.
 * - Memasang AndroidRouterBridge ke objek window JavaScript.
 * - Menangani status bar sporty biru (#0C44AC) dan permission Android.
 */
public class MainActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_CODE = 1933;
    private WebView webView;
    private AndroidRouterBridge routerBridge;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Styling status bar dengan warna biru khas Persib (#0C44AC)
        setupStatusBarColor();

        // Inisialisasi WebView utama
        webView = new WebView(this);
        setContentView(webView);

        // Konfigurasi WebSettings
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        webSettings.setUseWideViewPort(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setSupportZoom(false);
        webSettings.setBuiltInZoomControls(false);

        // Pasang Native Bridge ke window.AndroidRouterBridge dan window.AndroidBridge
        routerBridge = new AndroidRouterBridge(this);
        webView.addJavascriptInterface(routerBridge, "AndroidRouterBridge");
        webView.addJavascriptInterface(routerBridge, "AndroidBridge");

        // Konfigurasi WebViewClient
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Semua navigasi tetap di dalam WebView lokal
                return false;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
            }
        });

        webView.setWebChromeClient(new WebChromeClient());

        // Meminta izin runtime jaringan & lokasi (untuk SSID/BSSID pada Android 8.1 - 14+)
        requestRequiredPermissions();

        // Memuat aplikasi React/Vite lokal dari folder assets
        loadWebApp();
    }

    private void loadWebApp() {
        // Alamat aset lokal hasil build React/Vite
        String localAssetUrl = "file:///android_asset/public/index.html";
        webView.loadUrl(localAssetUrl);
    }

    private void setupStatusBarColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(Color.parseColor("#0C44AC"));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                // Gunakan teks putih pada status bar biru gelap
                View decor = window.getDecorView();
                decor.setSystemUiVisibility(0);
            }
        }
    }

    private void requestRequiredPermissions() {
        List<String> permissionsToRequest = new ArrayList<>();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.NEARBY_WIFI_DEVICES);
            }
        }

        if (!permissionsToRequest.isEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsToRequest.toArray(new String[0]), PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            // Beritahu WebView bahwa permission telah diperbarui jika diperlukan
            if (webView != null) {
                webView.evaluateJavascript("if (typeof runLocalNetworkCheck === 'function') { runLocalNetworkCheck(); }", null);
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
