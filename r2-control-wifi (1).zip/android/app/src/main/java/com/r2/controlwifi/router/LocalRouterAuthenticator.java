package com.r2.controlwifi.router;

import com.r2.controlwifi.network.WifiNetworkHelper;
import com.r2.controlwifi.security.SecureStorageManager;
import okhttp3.Credentials;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONObject;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/**
 * LocalRouterAuthenticator
 * 
 * Pengelola autentikasi router lokal secara aman.
 * 
 * Aturan Ketat:
 * 1. Komunikasi HANYA ke gateway lokal melalui Wi-Fi yang sedang aktif.
 * 2. Menolak IP publik, cloud, VPS, domain eksternal, atau koneksi lewat mobile data.
 * 3. Tidak membuat respons sukses palsu/mock (jika gagal atau belum didukung, laporkan status sebenarnya).
 * 4. Password tidak dicatat ke log, tidak dimasukkan ke URL, dan tidak disimpan sebagai plaintext.
 */
public class LocalRouterAuthenticator {

    private final WifiNetworkHelper networkHelper;
    private final SecureStorageManager secureStorage;
    private final OkHttpClient httpClient;

    public LocalRouterAuthenticator(WifiNetworkHelper networkHelper, SecureStorageManager secureStorage) {
        this.networkHelper = networkHelper;
        this.secureStorage = secureStorage;

        this.httpClient = new OkHttpClient.Builder()
                .connectTimeout(2500, TimeUnit.MILLISECONDS)
                .readTimeout(2500, TimeUnit.MILLISECONDS)
                .writeTimeout(2500, TimeUnit.MILLISECONDS)
                .followRedirects(true)
                .followSslRedirects(true)
                .build();
    }

    /**
     * Memeriksa apakah gateway lokal merespons pada socket port 80/443/8080
     */
    public boolean checkGatewayReachability(String gatewayIp) {
        if (!networkHelper.isConnectedToWifi()) {
            return false;
        }

        if (!WifiNetworkHelper.isPrivateIpv4(gatewayIp)) {
            return false;
        }

        int[] ports = {80, 443, 8080};
        for (int port : ports) {
            try (Socket socket = new Socket()) {
                socket.connect(new InetSocketAddress(gatewayIp, port), 1200);
                return true;
            } catch (IOException ignored) {
            }
        }
        return false;
    }

    /**
     * Memproses autentikasi ke router lokal.
     * Mengembalikan String JSON dengan struktur { success, message, expiresAt, sessionToken }
     */
    public String authenticate(String gatewayIp, String credentialsJson, String method) {
        JSONObject result = new JSONObject();

        try {
            // 1. Verifikasi koneksi Wi-Fi
            if (!networkHelper.isConnectedToWifi()) {
                result.put("success", false);
                result.put("message", "Kontrol router tidak tersedia - Perangkat tidak terhubung ke Wi-Fi.");
                return result.toString();
            }

            // 2. Validasi IP Gateway Lokal
            if (!WifiNetworkHelper.isPrivateIpv4(gatewayIp)) {
                result.put("success", false);
                result.put("message", "Alamat router tidak valid atau berada di luar jaringan lokal.");
                return result.toString();
            }

            // 3. Parsing kredensial dari memori aman (tanpa menulis ke log)
            JSONObject creds = new JSONObject(credentialsJson);
            String username = creds.optString("username", "").trim();
            String password = creds.optString("password", "");

            if (username.isEmpty() || password.isEmpty()) {
                result.put("success", false);
                result.put("message", "Nama pengguna dan password router harus diisi.");
                return result.toString();
            }

            // 4. Periksa apakah gateway merespons secara lokal
            boolean reachable = checkGatewayReachability(gatewayIp);
            if (!reachable) {
                result.put("success", false);
                result.put("message", "Gateway router lokal (" + gatewayIp + ") tidak merespons di jaringan Wi-Fi.");
                return result.toString();
            }

            // 5. Lakukan percobaan autentikasi standar (HTTP Basic / Web Auth lokal)
            boolean authSuccess = false;
            String failureReason = "";

            String[] probeUrls = {
                    "http://" + gatewayIp + "/",
                    "http://" + gatewayIp + "/login.html",
                    "http://" + gatewayIp + "/index.html",
                    "https://" + gatewayIp + "/"
            };

            for (String url : probeUrls) {
                try {
                    String credentialHeader = Credentials.basic(username, password);
                    Request request = new Request.Builder()
                            .url(url)
                            .header("Authorization", credentialHeader)
                            .header("User-Agent", "R2-Control-WiFi-Android/1.0")
                            .build();

                    try (Response response = httpClient.newCall(request).execute()) {
                        int code = response.code();
                        if (code >= 200 && code < 300) {
                            // Router menerima otentikasi
                            authSuccess = true;
                            break;
                        } else if (code == 401 || code == 403) {
                            failureReason = "Kredensial akun router ditolak oleh gateway.";
                        }
                    }
                } catch (Exception e) {
                    // Coba endpoint selanjutnya
                }
            }

            if (authSuccess) {
                // Buat token sesi aman berbasis hash lokal (bukan password plaintext)
                String sessionHash = generateLocalSessionHash(username, gatewayIp);

                // Masa berlaku sesi (misal 24 jam)
                Calendar cal = Calendar.getInstance();
                cal.add(Calendar.HOUR_OF_DAY, 24);
                String expiresAt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(cal.getTime());

                // Simpan ke SecureStorageManager
                secureStorage.savePairedRouter(
                        gatewayIp,
                        networkHelper.getSsid(),
                        networkHelper.getBssid(),
                        sessionHash,
                        expiresAt
                );

                result.put("success", true);
                result.put("message", "Router berhasil terhubung.");
                result.put("expiresAt", expiresAt);
                result.put("sessionToken", sessionHash);
                return result.toString();
            } else {
                result.put("success", false);
                result.put("message", failureReason.isEmpty()
                        ? "Metode autentikasi router belum diketahui atau membutuhkan adapter khusus."
                        : failureReason);
                return result.toString();
            }

        } catch (Exception e) {
            try {
                result.put("success", false);
                result.put("message", "Terjadi kesalahan pada native bridge: " + e.getMessage());
            } catch (Exception ignored) {
            }
            return result.toString();
        }
    }

    /**
     * Menghasilkan hash lokal sesi tanpa menyimpan password
     */
    private String generateLocalSessionHash(String username, String gatewayIp) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            String raw = username + ":" + gatewayIp + ":" + System.currentTimeMillis();
            byte[] hash = digest.digest(raw.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            return "sess_" + System.currentTimeMillis();
        }
    }
}
