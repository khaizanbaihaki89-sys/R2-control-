package com.r2.controlwifi.bridge;

import android.app.Activity;
import android.webkit.JavascriptInterface;
import com.r2.controlwifi.network.WifiNetworkHelper;
import com.r2.controlwifi.router.LocalRouterAuthenticator;
import com.r2.controlwifi.security.SecureStorageManager;
import org.json.JSONObject;

/**
 * AndroidRouterBridge
 * 
 * Jembatan Native Android (JavascriptInterface) untuk aplikasi R2 CONTROL WIFI.
 * Terikat ke objek JavaScript global:
 * - window.AndroidRouterBridge
 * - window.AndroidBridge
 * 
 * Mematuhi kontrak API yang didefinisikan pada:
 * src/services/androidNetworkBridge.ts
 */
public class AndroidRouterBridge {

    private final Activity activity;
    private final WifiNetworkHelper networkHelper;
    private final SecureStorageManager secureStorage;
    private final LocalRouterAuthenticator authenticator;

    public AndroidRouterBridge(Activity activity) {
        this.activity = activity;
        this.networkHelper = new WifiNetworkHelper(activity);
        this.secureStorage = new SecureStorageManager(activity);
        this.authenticator = new LocalRouterAuthenticator(this.networkHelper, this.secureStorage);
    }

    // ==========================================
    // 1. INFORMASI WI-FI & JARINGAN LOKAL
    // ==========================================

    @JavascriptInterface
    public boolean isConnectedToWifi() {
        return networkHelper.isConnectedToWifi();
    }

    @JavascriptInterface
    public String getSsid() {
        return networkHelper.getSsid();
    }

    @JavascriptInterface
    public String getBssid() {
        return networkHelper.getBssid();
    }

    @JavascriptInterface
    public String getDeviceIp() {
        return networkHelper.getDeviceIp();
    }

    @JavascriptInterface
    public String getGatewayIp() {
        return networkHelper.getGatewayIp();
    }

    @JavascriptInterface
    public String getSubnetMask() {
        return networkHelper.getSubnetMask();
    }

    @JavascriptInterface
    public int getLinkSpeed() {
        return networkHelper.getLinkSpeed();
    }

    @JavascriptInterface
    public int getFrequency() {
        return networkHelper.getFrequency();
    }

    @JavascriptInterface
    public boolean hasLocationPermission() {
        return networkHelper.hasLocationPermission();
    }

    // ==========================================
    // 2. KEMAMPUAN & KONEKSI GATEWAY ROUTER
    // ==========================================

    @JavascriptInterface
    public boolean checkGatewayReachability(String gatewayIp) {
        return authenticator.checkGatewayReachability(gatewayIp);
    }

    // ==========================================
    // 3. AUTENTIKASI ROUTER LOKAL
    // ==========================================

    @JavascriptInterface
    public String authenticateRouter(String gatewayIp, String credentialsJson, String method) {
        return authenticator.authenticate(gatewayIp, credentialsJson, method);
    }

    // ==========================================
    // 4. SESI ROUTER & SECURE STORAGE
    // ==========================================

    @JavascriptInterface
    public boolean endRouterSession(String gatewayIp) {
        secureStorage.clearSession();
        return true;
    }

    @JavascriptInterface
    public String getStoredSessionStatus(String gatewayIp) {
        JSONObject obj = new JSONObject();
        try {
            boolean isWifi = networkHelper.isConnectedToWifi();
            if (!isWifi) {
                obj.put("paired", false);
                obj.put("status", "OFFLINE");
                obj.put("message", "Perangkat tidak terhubung ke Wi-Fi");
                return obj.toString();
            }

            String pairedJson = secureStorage.getPairedRouterJson();
            if (pairedJson == null) {
                obj.put("paired", false);
                obj.put("status", "UNPAIRED");
                return obj.toString();
            }

            JSONObject paired = new JSONObject(pairedJson);
            String savedGw = paired.optString("gatewayIp", "");

            if (!savedGw.equals(gatewayIp)) {
                obj.put("paired", true);
                obj.put("valid", false);
                obj.put("status", "DIFFERENT_WIFI");
                obj.put("message", "Router rumah tidak tersedia");
                return obj.toString();
            }

            boolean active = secureStorage.hasActiveSession(gatewayIp);
            if (!active) {
                obj.put("paired", true);
                obj.put("valid", false);
                obj.put("status", "SESSION_EXPIRED");
                obj.put("message", "Sesi router telah berakhir.");
                return obj.toString();
            }

            obj.put("paired", true);
            obj.put("valid", true);
            obj.put("status", "MATCH");
            obj.put("gatewayIp", savedGw);
            obj.put("ssid", paired.optString("ssid", ""));
            obj.put("bssid", paired.optString("bssid", ""));
            return obj.toString();

        } catch (Exception e) {
            try {
                obj.put("paired", false);
                obj.put("status", "ERROR");
                obj.put("message", e.getMessage());
            } catch (Exception ignored) {
            }
            return obj.toString();
        }
    }
}
