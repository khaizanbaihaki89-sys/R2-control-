package com.r2.controlwifi.network;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.DhcpInfo;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.RouteInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import androidx.core.content.ContextCompat;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;

/**
 * WifiNetworkHelper
 * 
 * Pengelola deteksi jaringan Wi-Fi lokal Android.
 * - Membaca SSID, BSSID, Device IP, Gateway IP, Subnet Mask, Link Speed, Frekuensi.
 * - Menangani batasan Android 8.1 - 14+ tanpa crash (mengembalikan "Tidak tersedia").
 * - Memastikan hanya berkomunikasi melalui Wi-Fi lokal, bukan mobile data / internet.
 */
public class WifiNetworkHelper {

    private final Context context;
    private final WifiManager wifiManager;
    private final ConnectivityManager connectivityManager;

    public WifiNetworkHelper(Context context) {
        this.context = context.getApplicationContext();
        this.wifiManager = (WifiManager) this.context.getSystemService(Context.WIFI_SERVICE);
        this.connectivityManager = (ConnectivityManager) this.context.getSystemService(Context.CONNECTIVITY_SERVICE);
    }

    /**
     * Memeriksa apakah perangkat terhubung secara aktif ke Wi-Fi.
     * Mobile data tidak diizinkan sebagai jalur kontrol router.
     */
    public boolean isConnectedToWifi() {
        if (connectivityManager == null) return false;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Network activeNetwork = connectivityManager.getActiveNetwork();
            if (activeNetwork == null) return false;
            NetworkCapabilities capabilities = connectivityManager.getNetworkCapabilities(activeNetwork);
            return capabilities != null && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
        } else {
            android.net.NetworkInfo networkInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            return networkInfo != null && networkInfo.isConnected();
        }
    }

    /**
     * Memeriksa apakah aplikasi memiliki izin lokasi (diperlukan Android untuk SSID/BSSID)
     */
    public boolean hasLocationPermission() {
        boolean fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        boolean coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        return fine || coarse;
    }

    /**
     * Mendapatkan nama Wi-Fi (SSID)
     */
    public String getSsid() {
        if (!isConnectedToWifi() || wifiManager == null) {
            return "Tidak tersedia";
        }

        try {
            WifiInfo info = wifiManager.getConnectionInfo();
            if (info != null) {
                String ssid = info.getSSID();
                if (ssid != null && !ssid.isEmpty() && !ssid.equals("<unknown ssid>") && !ssid.equals("\"<unknown ssid>\"")) {
                    return ssid.replace("\"", "");
                }
            }
        } catch (Exception ignored) {
        }
        return "Tidak tersedia";
    }

    /**
     * Mendapatkan alamat MAC Wi-Fi router (BSSID)
     */
    public String getBssid() {
        if (!isConnectedToWifi() || wifiManager == null) {
            return "Tidak tersedia";
        }

        try {
            WifiInfo info = wifiManager.getConnectionInfo();
            if (info != null) {
                String bssid = info.getBSSID();
                if (bssid != null && !bssid.isEmpty() && !bssid.equals("02:00:00:00:00:00")) {
                    return bssid;
                }
            }
        } catch (Exception ignored) {
        }
        return "Tidak tersedia";
    }

    /**
     * Mendapatkan alamat IP perangkat di jaringan lokal LAN
     */
    public String getDeviceIp() {
        if (!isConnectedToWifi()) {
            return "Tidak tersedia";
        }

        // 1. Coba dari LinkProperties
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && connectivityManager != null) {
            Network activeNetwork = connectivityManager.getActiveNetwork();
            if (activeNetwork != null) {
                LinkProperties linkProperties = connectivityManager.getLinkProperties(activeNetwork);
                if (linkProperties != null) {
                    for (LinkAddress linkAddress : linkProperties.getLinkAddresses()) {
                        InetAddress address = linkAddress.getAddress();
                        if (address instanceof Inet4Address && !address.isLoopbackAddress()) {
                            return address.getHostAddress();
                        }
                    }
                }
            }
        }

        // 2. Coba dari NetworkInterface lokal
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                if (intf.getName().toLowerCase().contains("wlan") || intf.getName().toLowerCase().contains("wifi")) {
                    List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
                    for (InetAddress addr : addrs) {
                        if (!addr.isLoopbackAddress() && addr instanceof Inet4Address) {
                            return addr.getHostAddress();
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }

        // 3. Fallback dari WifiManager DhcpInfo
        if (wifiManager != null) {
            WifiInfo info = wifiManager.getConnectionInfo();
            if (info != null) {
                int ip = info.getIpAddress();
                if (ip != 0) {
                    return formatIpAddress(ip);
                }
            }
        }

        return "Tidak tersedia";
    }

    /**
     * Mendapatkan default gateway IP router lokal
     */
    public String getGatewayIp() {
        if (!isConnectedToWifi()) {
            return "Tidak tersedia";
        }

        // 1. Coba dari LinkProperties route default
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && connectivityManager != null) {
            Network activeNetwork = connectivityManager.getActiveNetwork();
            if (activeNetwork != null) {
                LinkProperties linkProperties = connectivityManager.getLinkProperties(activeNetwork);
                if (linkProperties != null) {
                    for (RouteInfo route : linkProperties.getRoutes()) {
                        if (route.isDefaultRoute() && route.getGateway() instanceof Inet4Address) {
                            String gw = route.getGateway().getHostAddress();
                            if (gw != null && !gw.equals("0.0.0.0")) {
                                return gw;
                            }
                        }
                    }
                }
            }
        }

        // 2. Coba dari DhcpInfo
        if (wifiManager != null) {
            DhcpInfo dhcpInfo = wifiManager.getDhcpInfo();
            if (dhcpInfo != null && dhcpInfo.gateway != 0) {
                return formatIpAddress(dhcpInfo.gateway);
            }
        }

        // 3. Turunkan dari IP perangkat jika 3 oktet pertama diketahui
        String deviceIp = getDeviceIp();
        if (deviceIp != null && !deviceIp.equals("Tidak tersedia")) {
            String[] parts = deviceIp.split("\\.");
            if (parts.length == 4) {
                return parts[0] + "." + parts[1] + "." + parts[2] + ".1";
            }
        }

        return "192.168.1.1";
    }

    /**
     * Mendapatkan Subnet Mask lokal
     */
    public String getSubnetMask() {
        if (!isConnectedToWifi() || wifiManager == null) {
            return "255.255.255.0";
        }

        DhcpInfo dhcp = wifiManager.getDhcpInfo();
        if (dhcp != null && dhcp.netmask != 0) {
            return formatIpAddress(dhcp.netmask);
        }
        return "255.255.255.0";
    }

    /**
     * Kecepatan link Wi-Fi dalam Mbps
     */
    public int getLinkSpeed() {
        if (!isConnectedToWifi() || wifiManager == null) return 0;
        try {
            WifiInfo info = wifiManager.getConnectionInfo();
            return info != null ? info.getLinkSpeed() : 0;
        } catch (Exception ignored) {
            return 0;
        }
    }

    /**
     * Frekuensi Wi-Fi dalam MHz
     */
    public int getFrequency() {
        if (!isConnectedToWifi() || wifiManager == null) return 0;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                WifiInfo info = wifiManager.getConnectionInfo();
                return info != null ? info.getFrequency() : 0;
            } catch (Exception ignored) {
                return 0;
            }
        }
        return 0;
    }

    /**
     * Memeriksa apakah IP yang diberikan adalah alamat IPv4 privat LAN (RFC 1918)
     */
    public static boolean isPrivateIpv4(String ip) {
        if (ip == null || ip.isEmpty()) return false;
        String[] parts = ip.split("\\.");
        if (parts.length != 4) return false;

        try {
            int p0 = Integer.parseInt(parts[0]);
            int p1 = Integer.parseInt(parts[1]);

            // 10.0.0.0/8
            if (p0 == 10) return true;
            // 172.16.0.0/12
            if (p0 == 172 && p1 >= 16 && p1 <= 31) return true;
            // 192.168.0.0/16
            if (p0 == 192 && p1 == 168) return true;
            // 169.254.0.0/16 (Link local)
            if (p0 == 169 && p1 == 254) return true;
        } catch (NumberFormatException ignored) {
            return false;
        }
        return false;
    }

    private String formatIpAddress(int ip) {
        return (ip & 0xFF) + "." +
                ((ip >> 8) & 0xFF) + "." +
                ((ip >> 16) & 0xFF) + "." +
                ((ip >> 24) & 0xFF);
    }
}
