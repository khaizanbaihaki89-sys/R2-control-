package com.r2.controlwifi.security;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKeys;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * SecureStorageManager
 * 
 * Pengelola penyimpanan aman (Android Keystore / EncryptedSharedPreferences).
 * - Menyimpan metadata sesi router rumah yang telah di-pairing.
 * - Password router TIDAK PERNAH disimpan sebagai plaintext.
 * - Tidak mencatat password / token ke Logcat / console.
 */
public class SecureStorageManager {

    private static final String PREF_FILE_NAME = "r2_secure_router_prefs";
    private static final String KEY_GATEWAY_IP = "paired_gateway_ip";
    private static final String KEY_SSID = "paired_ssid";
    private static final String KEY_BSSID = "paired_bssid";
    private static final String KEY_PAIRED_AT = "paired_at";
    private static final String KEY_SESSION_TOKEN = "session_token";
    private static final String KEY_EXPIRES_AT = "expires_at";

    private SharedPreferences preferences;

    public SecureStorageManager(Context context) {
        try {
            String masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC);
            this.preferences = EncryptedSharedPreferences.create(
                    PREF_FILE_NAME,
                    masterKeyAlias,
                    context,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        } catch (Exception e) {
            // Fallback ke standard SharedPreferences jika runtime perangkat tidak mendukung Keystore Hardware
            this.preferences = context.getSharedPreferences(PREF_FILE_NAME, Context.MODE_PRIVATE);
        }
    }

    /**
     * Menyimpan sesi router yang berhasil diautentikasi
     */
    public void savePairedRouter(String gatewayIp, String ssid, String bssid, String sessionToken, String expiresAt) {
        if (preferences == null) return;

        String now = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(new Date());

        preferences.edit()
                .putString(KEY_GATEWAY_IP, gatewayIp != null ? gatewayIp : "")
                .putString(KEY_SSID, ssid != null ? ssid : "")
                .putString(KEY_BSSID, bssid != null ? bssid : "")
                .putString(KEY_SESSION_TOKEN, sessionToken != null ? sessionToken : "")
                .putString(KEY_PAIRED_AT, now)
                .putString(KEY_EXPIRES_AT, expiresAt != null ? expiresAt : "")
                .apply();
    }

    /**
     * Mendapatkan data router terdaftar dalam format JSON
     */
    public String getPairedRouterJson() {
        if (preferences == null) return null;

        String gatewayIp = preferences.getString(KEY_GATEWAY_IP, null);
        if (gatewayIp == null || gatewayIp.isEmpty()) {
            return null;
        }

        try {
            JSONObject obj = new JSONObject();
            obj.put("gatewayIp", gatewayIp);
            obj.put("ssid", preferences.getString(KEY_SSID, ""));
            obj.put("bssid", preferences.getString(KEY_BSSID, ""));
            obj.put("pairedAt", preferences.getString(KEY_PAIRED_AT, ""));
            obj.put("expiresAt", preferences.getString(KEY_EXPIRES_AT, ""));
            return obj.toString();
        } catch (Exception ignored) {
            return null;
        }
    }

    /**
     * Memeriksa apakah ada router terdaftar pada gateway ini dan sesi masih berlaku
     */
    public boolean hasActiveSession(String currentGatewayIp) {
        if (preferences == null) return false;

        String savedGateway = preferences.getString(KEY_GATEWAY_IP, null);
        if (savedGateway == null || !savedGateway.equals(currentGatewayIp)) {
            return false;
        }

        String expiresAtStr = preferences.getString(KEY_EXPIRES_AT, null);
        if (expiresAtStr != null && !expiresAtStr.isEmpty()) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
                Date expDate = sdf.parse(expiresAtStr);
                if (expDate != null && expDate.before(new Date())) {
                    return false; // Sesi telah kedaluwarsa
                }
            } catch (Exception ignored) {
            }
        }

        return true;
    }

    /**
     * Menghapus sesi router aktif (Logout)
     */
    public void clearSession() {
        if (preferences != null) {
            preferences.edit().clear().apply();
        }
    }

    public String getPairedGatewayIp() {
        return preferences != null ? preferences.getString(KEY_GATEWAY_IP, null) : null;
    }

    public String getPairedSsid() {
        return preferences != null ? preferences.getString(KEY_SSID, null) : null;
    }
}
